<?php
header('Content-Type: text/html; charset=UTF-8');
mb_internal_encoding('UTF-8');
mb_http_output('UTF-8');
require_once __DIR__ . '/../../src/config.php';
require_once __DIR__ . '/../../src/csrf.php';
require_once __DIR__ . '/../../src/layout.php';
require_login();
$user = current_user();
if ($user['user_type'] !== 'teacher') { http_response_code(403); echo 'Forbidden'; exit; }

$paperId = (int)($_GET['paper_id'] ?? 0);
if (!$paperId) { echo 'Missing paper'; exit; }
$pdo = db();

// Fetch paper and questions
$pStmt = $pdo->prepare('SELECT id, title, fee_cents, time_limit_seconds, is_published FROM papers WHERE id=? AND teacher_id=?');
$pStmt->execute([$paperId, $user['id']]);
$paper = $pStmt->fetch();
if (!$paper) { echo 'Paper not found'; exit; }

$qStmt = $pdo->prepare('SELECT id, question_text, marks, position, image_path FROM questions WHERE paper_id=? ORDER BY position');
$qStmt->execute([$paperId]);
$questions = $qStmt->fetchAll();
$oStmt = $pdo->prepare('SELECT id, option_text, is_correct, attachment_path FROM answer_options WHERE question_id=? ORDER BY id');
foreach ($questions as &$q) {
    $oStmt->execute([$q['id']]);
    $q['options'] = $oStmt->fetchAll();
}
unset($q);

$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $isAutosave = (($_POST['autosave'] ?? '') === '1');
  if (!csrf_verify()) {
    if ($isAutosave) {
      header('Content-Type: application/json');
      http_response_code(400);
      echo json_encode(['ok' => false, 'error' => 'Invalid CSRF token', 'csrf' => csrf_token()]);
      exit;
    }
    $errors[] = 'Invalid CSRF token';
  }
    $title = trim($_POST['title'] ?? '');
    $fee = (int)($_POST['fee_cents'] ?? 0);
    $timeLimit = (int)($_POST['time_limit_minutes'] ?? 0) * 60;
    $publish = isset($_POST['publish']) ? 1 : 0;
    $questionsIn = $_POST['questions'] ?? [];
    $optionsIn = $_POST['options'] ?? [];
    $correctIn = $_POST['correct'] ?? [];
    $marksIn = $_POST['marks'] ?? [];

    if (!$isAutosave) {
      if (!$title || $timeLimit <= 0) { $errors[] = 'Title and time limit required.'; }
      if (empty($questionsIn)) { $errors[] = 'At least one question required.'; }

      // Server-side correct answer validation
      foreach ($questionsIn as $i => $qText) {
        $opts = $optionsIn[$i] ?? [];
        if (empty($opts)) { $errors[] = 'Each question needs options.'; break; }
        if (!isset($correctIn[$i])) { $errors[] = 'Select a correct option for every question.'; break; }
      }
    } else {
      // Autosave: tolerate partial data; normalize minimal time
      if ($timeLimit <= 0) { $timeLimit = 60; }
    }
         
    if (!$errors) {
        try {
            $pdo->beginTransaction();
        if ($isAutosave) {
          // Do not change publish state during autosave
          $u = $pdo->prepare('UPDATE papers SET title=?, fee_cents=?, time_limit_seconds=? WHERE id=? AND teacher_id=?');
          $u->execute([$title, $fee, $timeLimit, $paperId, $user['id']]);
        } else {
          $u = $pdo->prepare('UPDATE papers SET title=?, fee_cents=?, time_limit_seconds=?, is_published=? WHERE id=? AND teacher_id=?');
          $u->execute([$title, $fee, $timeLimit, $publish, $paperId, $user['id']]);
        }

        if (!$isAutosave) {
          // Remove old questions/options only on manual save
          $pdo->prepare('DELETE FROM questions WHERE paper_id=?')->execute([$paperId]);

          // Build question list with positions and reorder based on insert_position values
          $questionsToInsert = [];
          $positionsIn = $_POST['insert_position'] ?? [];
          
          foreach ($questionsIn as $i => $qText) {
            $qText = trim($qText);
            if ($qText === '') { continue; }
            $marks = (int)($marksIn[$i] ?? 1); if ($marks < 1) { $marks = 1; }
            
            // Get requested insert position
            $requestedPos = isset($positionsIn[$i]) ? (int)$positionsIn[$i] : count($questionsToInsert) + 1;
            
            // Handle image upload for question
            $existingImages = $_POST['existing_images'] ?? [];
            $imagePath = trim((string)($existingImages[$i] ?? '')) ?: null;
            if (isset($_FILES['question_images']) && isset($_FILES['question_images']['tmp_name'][$i]) && $_FILES['question_images']['tmp_name'][$i]) {
              $file = $_FILES['question_images'];
              $tmpFile = $file['tmp_name'][$i];
              $fileName = $file['name'][$i];
              $fileType = pathinfo($fileName, PATHINFO_EXTENSION);
                        
              // Validate image and PDF
              if (in_array(strtolower($fileType), ['jpg', 'jpeg', 'png', 'gif', 'webp', 'pdf'])) {
                $newFileName = 'q_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $fileType;
                $uploadDir = __DIR__ . '/uploads/questions/';
                if (!is_dir($uploadDir)) @mkdir($uploadDir, 0755, true);
                            
                $destFile = $uploadDir . $newFileName;
                if (move_uploaded_file($tmpFile, $destFile)) {
                  $imagePath = 'uploads/questions/' . $newFileName;
                }
              }
            }
            
            $optFiles = $_FILES['option_attachments'] ?? null;
            $existingOptAttachments = $_POST['existing_option_attachments'] ?? [];
            $optTexts = $optionsIn[$i] ?? [];
            $optsForQuestion = [];
            foreach ($optTexts as $j => $optText) {
              $optText = (string)$optText;
              $optAttachmentPath = trim((string)($existingOptAttachments[$i][$j] ?? '')) ?: null;
              if ($optFiles && isset($optFiles['tmp_name'][$i][$j]) && $optFiles['tmp_name'][$i][$j]) {
                $tmpFile = $optFiles['tmp_name'][$i][$j];
                $fileName = $optFiles['name'][$i][$j] ?? '';
                $fileType = pathinfo($fileName, PATHINFO_EXTENSION);
                if (in_array(strtolower($fileType), ['jpg', 'jpeg', 'png', 'gif', 'webp', 'pdf'])) {
                  $newFileName = 'opt_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $fileType;
                  $uploadDir = __DIR__ . '/uploads/options/';
                  if (!is_dir($uploadDir)) @mkdir($uploadDir, 0755, true);
                  $destFile = $uploadDir . $newFileName;
                  if (move_uploaded_file($tmpFile, $destFile)) {
                    $optAttachmentPath = 'uploads/options/' . $newFileName;
                  }
                }
              }
              $optsForQuestion[] = ['text' => $optText, 'attachment' => $optAttachmentPath, 'index' => $j];
            }

            $questionsToInsert[] = [
              'text' => $qText,
              'marks' => $marks,
              'position' => $requestedPos,
              'image' => $imagePath,
              'options' => $optsForQuestion,
              'correct' => $correctIn[$i] ?? ''
            ];
          }
          
          // Sort questions by requested position
          usort($questionsToInsert, function($a, $b) {
            return $a['position'] - $b['position'];
          });
          
          // Reinsert questions and options with correct positions
          $qIns = $pdo->prepare('INSERT INTO questions (paper_id, question_text, marks, position, image_path) VALUES (?,?,?,?,?)');
          $oIns = $pdo->prepare('INSERT INTO answer_options (question_id, option_text, is_correct, attachment_path) VALUES (?,?,?,?)');
          
          foreach ($questionsToInsert as $idx => $q) {
            $qIns->execute([$paperId, $q['text'], $q['marks'], $idx + 1, $q['image']]);
            $newQid = $pdo->lastInsertId();
            foreach ($q['options'] as $opt) {
              $isCorrect = ((string)$q['correct'] === (string)$opt['index']) ? 1 : 0;
              $oIns->execute([$newQid, trim((string)$opt['text']), $isCorrect, $opt['attachment']]);
            }
          }
        }

            $pdo->commit();
        if ($isAutosave) {
          header('Content-Type: application/json');
          echo json_encode(['ok' => true, 'paper_id' => $paperId, 'csrf' => csrf_token()]);
          exit;
        } else {
          $success = 'Paper updated.';
          // Refresh data for display
          header('Location: ' . app_href('teacher/edit_paper.php?paper_id=' . $paperId . '&saved=1'));
          exit;
        }
        } catch (Throwable $e) {
            $pdo->rollBack();
        if ($isAutosave) {
          header('Content-Type: application/json');
          http_response_code(500);
          echo json_encode(['ok' => false, 'error' => 'Error updating paper: ' . $e->getMessage(), 'csrf' => csrf_token()]);
          exit;
        } else {
          $errors[] = 'Error updating paper: ' . $e->getMessage();
        }
        }
    }
}

$paperJson = json_encode($paper);
$questionsJson = json_encode($questions);
render_header('Edit Paper');
?>

<!-- Load jQuery first for MathQuill -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<!-- MathQuill CSS & JS for visual math editor -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/mathquill/0.10.1/mathquill.min.css" crossorigin="anonymous" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/mathquill/0.10.1/mathquill.min.js" crossorigin="anonymous"></script>

<!-- Load KaTeX for math rendering -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.css" />
<script src="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/contrib/auto-render.min.js"></script>

<script>
  // Initialize KaTeX rendering when script loads
  function renderMath() {
    if (window.renderMathInElement) {
      try {
        window.renderMathInElement(document.body, {
          delimiters: [
            {left: '$$', right: '$$', display: true},
            {left: '$', right: '$', display: false},
            {left: '\\[', right: '\\]', display: true},
            {left: '\\(', right: '\\)', display: false}
          ],
          throwOnError: false
        });
      } catch(err) {
        console.log('KaTeX render error:', err.message);
      }
    }
  }
  
  // Render when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', renderMath);
  } else {
    renderMath();
  }
</script>

<section class="mb-4">
  <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-2">
    <div>
      <p class="text-uppercase small text-muted mb-1">Editing Paper</p>
      <h1 class="h4 mb-0"><?= htmlspecialchars($paper['title']) ?></h1>
    </div>
    <div class="d-flex gap-2">
      <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(app_href('teacher/manage_papers.php')) ?>">Back to list</a>
    </div>
  </div>
</section>
<section class="app-card p-4">
  <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-3">
    <h2 class="h5 mb-0">Paper Details</h2>
    <span class="badge-soft <?= $paper['is_published'] ? 'success' : 'muted' ?>"><?= $paper['is_published'] ? 'Published' : 'Draft' ?></span>
  </div>
  <?php if (isset($_GET['saved'])): ?><div class="alert alert-success">Saved successfully.</div><?php endif; ?>
  <?php foreach ($errors as $e): ?><div class="alert alert-danger" role="alert" aria-live="assertive"><?= htmlspecialchars($e) ?></div><?php endforeach; ?>
  <?php if ($success): ?><div class="alert alert-success" role="status" aria-live="polite"><?= htmlspecialchars($success) ?></div><?php endif; ?>
    <form method="post" id="editForm" enctype="multipart/form-data" accept-charset="UTF-8">
    <?= csrf_field(); ?>
    <div class="row g-3">
      <div class="col-lg-6">
        <label class="form-label">Title</label>
        <input class="form-control" name="title" id="title" required>
      </div>
      <div class="col-6 col-lg-3">
        <label class="form-label">Fee (cents)</label>
        <input type="number" class="form-control" name="fee_cents" id="fee_cents" min="0" value="0">
      </div>
      <div class="col-6 col-lg-3">
        <label class="form-label">Time Limit (minutes)</label>
        <input type="number" class="form-control" name="time_limit_minutes" id="time_limit_minutes" min="1" required>
      </div>
      <div class="col-12 form-check ps-2">
        <input type="checkbox" class="form-check-input" id="publishNow" name="publish" value="1">
        <label class="form-check-label" for="publishNow">Publish immediately</label>
      </div>
    </div>
    <hr class="my-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h3 class="h6 mb-0">Questions</h3>
      <button type="button" class="btn btn-primary btn-sm d-inline-flex align-items-center gap-2" onclick="addQuestion()"><i class="bi bi-plus-circle"></i> Add Question</button>
    </div>
    <div id="questions" class="d-flex flex-column gap-3" aria-live="polite"></div>
    <div class="d-flex flex-wrap gap-2 mt-4">
      <button type="submit" class="btn btn-primary d-inline-flex align-items-center gap-2"><i class="bi bi-save"></i> Save Changes</button>
      <button type="button" class="btn btn-outline-secondary" onclick="addQuestion()">Add Question</button>
    </div>
    <p class="muted small mt-3 mb-0"><strong>Reminder:</strong> You must select the correct answer using the radio button next to it. Submissions without a marked correct answer will be blocked.</p>
  </form>
</section>
<script>
const paperData = <?= $paperJson ?>;
const questionsData = <?= $questionsJson ?>;
let qIndex = 0;

// Autosave (LocalStorage)
const draftKey = 'edit_paper_draft_' + (paperData && paperData.id ? paperData.id : 'unknown');
function debounce(fn, delay){ let t; return function(){ clearTimeout(t); t = setTimeout(fn, delay); }; }
const debounceSaveDraft = debounce(saveDraft, 500);

function saveDraft(){
  try {
    const title = document.getElementById('title')?.value || '';
    const fee = document.getElementById('fee_cents')?.value || '';
    const time = document.getElementById('time_limit_minutes')?.value || '';
    const publish = document.getElementById('publishNow')?.checked ? 1 : 0;

    const questions = [];
    document.querySelectorAll('.question-card').forEach((card, idx) => {
      const qText = card.querySelector('.question-text')?.value || '';
      const marksInput = card.querySelector(`input[name="marks[${idx}]"]`);
      const marks = marksInput ? parseInt(marksInput.value || '1', 10) : 1;
      const existingImgInput = card.querySelector(`input[name="existing_images[${idx}]"]`);
      const image_path = existingImgInput ? existingImgInput.value : '';
      const optsWrap = card.querySelector(`#opts_${idx}`);
      const optGroups = optsWrap ? Array.from(optsWrap.querySelectorAll('.input-group')) : [];
      const options = optGroups.map((g, j) => ({
        option_text: (g.querySelector('input[type="text"]')?.value || ''),
        attachment_path: (g.querySelector('input[type="hidden"]')?.value || ''),
        is_correct: (g.querySelector(`input[type="radio"][name="correct[${idx}]"]`)?.checked) || false
      }));
      let correctIndex = -1;
      options.forEach((o, j) => { if (o.is_correct) correctIndex = j; });
      questions.push({ question_text: qText, marks, options, correctIndex, image_path });
    });

    const payload = { title, fee_cents: fee, time_limit_minutes: time, publish, questions, ts: Date.now() };
    localStorage.setItem(draftKey, JSON.stringify(payload));
    const el = document.getElementById('autosaveStatus');
    if (el) { el.textContent = 'Draft saved at ' + new Date().toLocaleTimeString(); }
  } catch (e) { /* ignore */ }
}

function loadDraft(){
  try {
    const raw = localStorage.getItem(draftKey);
    if (!raw) return false;
    const data = JSON.parse(raw);
    const titleInput = document.getElementById('title');
    const feeInput = document.getElementById('fee_cents');
    const timeInput = document.getElementById('time_limit_minutes');
    const publishInput = document.getElementById('publishNow');
    if (titleInput && typeof data.title === 'string') titleInput.value = data.title;
    if (feeInput && typeof data.fee_cents !== 'undefined') feeInput.value = data.fee_cents;
    if (timeInput && typeof data.time_limit_minutes !== 'undefined') timeInput.value = Math.max(1, parseInt(data.time_limit_minutes || '1', 10));
    if (publishInput) publishInput.checked = false; // avoid accidental publish on restore

    const container = document.getElementById('questions');
    if (container && Array.isArray(data.questions)) {
      container.innerHTML = '';
      qIndex = 0;
      const baseQuestions = Array.isArray(window.questionsData) ? window.questionsData : [];
      data.questions.forEach((q, i) => {
        const baseOpts = (baseQuestions[i] && Array.isArray(baseQuestions[i].options)) ? baseQuestions[i].options : [];
        const opts = Array.isArray(q.options) ? q.options.map((o, j) => ({
          option_text: o.option_text || '',
          attachment_path: o.attachment_path || (baseOpts[j] ? (baseOpts[j].attachment_path || '') : ''),
          is_correct: (q.correctIndex === j)
        })) : [];
        const base = baseQuestions[i] || {};
        const imagePath = q.image_path || base.image_path || '';
        const qData = { question_text: q.question_text || '', marks: q.marks || 1, options: opts, image_path: imagePath };
        addQuestion(qData);
      });
      // After all questions added, set existing_images and display previews
      setTimeout(() => {
        data.questions.forEach((q, i) => {
          const imagePath = q.image_path || (baseQuestions[i] ? baseQuestions[i].image_path : '');
          if (imagePath) {
            const existingInput = document.querySelector(`input[name="existing_images[${i}]"]`);
            if (existingInput) existingInput.value = imagePath;
            const isPdf = /\.pdf$/i.test(imagePath);
            showAttachmentPreview(i, imagePath, isPdf);
          }
        });
      }, 0);
    }
    return true;
  } catch (e) { return false; }
}

function clearDraft(){ try { localStorage.removeItem(draftKey); } catch(e){} }

// Math equation templates
const mathTemplates = {
  'Quadratic Formula': '$$x = \\frac{-b \\pm \\sqrt{b^2-4ac}}{2a}$$',
  'Pythagorean Theorem': '$$a^2 + b^2 = c^2$$',
  'Fraction': '$$\\frac{numerator}{denominator}$$',
  'Square Root': '$$\\sqrt{x}$$',
  'Superscript': '$$x^n$$',
  'Greek Letters': '$$\\alpha, \\beta, \\gamma, \\pi, \\omega$$',
  'Integral': '$$\\int_a^b f(x) \\, dx$$',
  'Summation': '$$\\sum_{i=1}^{n} a_i$$',
};

function showMathHelper(btn) {
  const textarea = btn.closest('div').querySelector('.question-text');
  const modal = document.createElement('div');
  modal.style.cssText = 'position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.7); display: flex; align-items: center; justify-content: center; z-index: 9999; padding: 1rem;';
  
  // Symbol categories like Google Forms
  const symbolCategories = {
    'Basic': [
      {char: '+', latex: '+'},
      {char: '−', latex: '-'},
      {char: '×', latex: '\\times'},
      {char: '÷', latex: '\\div'},
      {char: '=', latex: '='},
      {char: '≠', latex: '\\neq'},
      {char: '>', latex: '>'},
      {char: '<', latex: '<'},
      {char: '≥', latex: '\\geq'},
      {char: '≤', latex: '\\leq'},
    ],
    'Fractions & Roots': [
      {char: '⁄', latex: '\\frac{}{}'},
      {char: '√', latex: '\\sqrt{}'},
      {char: '∛', latex: '\\sqrt[3]{}'},
      {char: '∜', latex: '\\sqrt[4]{}'},
    ],
    'Exponents & Subscripts': [
      {char: 'x²', latex: '^2'},
      {char: 'xⁿ', latex: '^{}'},
      {char: 'x₂', latex: '_{}'},
      {char: '()', latex: '()'},
      {char: '[]', latex: '[]'},
    ],
    'Greek Letters': [
      {char: 'α', latex: '\\alpha'},
      {char: 'β', latex: '\\beta'},
      {char: 'γ', latex: '\\gamma'},
      {char: 'δ', latex: '\\delta'},
      {char: 'π', latex: '\\pi'},
      {char: 'Σ', latex: '\\Sigma'},
      {char: 'θ', latex: '\\theta'},
      {char: 'ω', latex: '\\omega'},
      {char: 'λ', latex: '\\lambda'},
      {char: 'μ', latex: '\\mu'},
    ],
    'Calculus': [
      {char: '∫', latex: '\\int'},
      {char: '∫∫', latex: '\\iint'},
      {char: '∑', latex: '\\sum'},
      {char: 'Π', latex: '\\prod'},
      {char: '∞', latex: '\\infty'},
      {char: '∂', latex: '\\partial'},
      {char: '∇', latex: '\\nabla'},
      {char: '∆', latex: '\\Delta'},
    ],
    'Logic & Sets': [
      {char: '∀', latex: '\\forall'},
      {char: '∃', latex: '\\exists'},
      {char: '∈', latex: '\\in'},
      {char: '∉', latex: '\\notin'},
      {char: '⊂', latex: '\\subset'},
      {char: '∪', latex: '\\cup'},
      {char: '∩', latex: '\\cap'},
      {char: '∅', latex: '\\emptyset'},
    ],
    'Arrows': [
      {char: '←', latex: '\\leftarrow'},
      {char: '→', latex: '\\rightarrow'},
      {char: '↑', latex: '\\uparrow'},
      {char: '↓', latex: '\\downarrow'},
      {char: '⇒', latex: '\\Rightarrow'},
      {char: '⟹', latex: '\\implies'},
    ],
  };
  
  let htmlContent = `
    <div style="background: white; border-radius: 12px; padding: 0; max-width: 900px; box-shadow: 0 10px 40px rgba(0,0,0,0.3); max-height: 85vh; overflow: hidden; display: flex; flex-direction: column;">
      <div style="background: white; border-bottom: 2px solid #3b82f6; padding: 1.5rem; display: flex; justify-content: space-between; align-items: center;">
        <h4 style="margin: 0; font-weight: 700; font-size: 1.2rem; color: #1f2937;"><i class="bi bi-calculator-fill me-2" style="color: #3b82f6;"></i>Insert Math Equation</h4>
        <button type="button" style="background: none; border: none; font-size: 1.8rem; cursor: pointer; color: #6b7280; opacity: 0.8;" onclick="this.closest('[style*=position]').remove()">×</button>
      </div>
      <div style="background: #f8f9fa; padding: 1rem; border-bottom: 1px solid #e9ecef;">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
          <div>
            <label style="display: block; margin-bottom: 0.5rem; font-weight: 600; color: #333; font-size: 0.9rem;">LaTeX Code</label>
            <input type="text" id="latexInput" placeholder="e.g., x = \\frac{-b \\pm \\sqrt{b^2-4ac}}{2a}" style="width: 100%; border-radius: 6px; border: 1px solid #ddd; padding: 0.75rem; font-family: monospace; font-size: 0.9rem; min-height: 44px;" />
            <small style="display: block; margin-top: 0.5rem; color: #666; font-size: 0.85rem;">Type or click symbols below</small>
          </div>
          <div>
            <label style="display: block; margin-bottom: 0.5rem; font-weight: 600; color: #333; font-size: 0.9rem;">Live Preview</label>
            <div id="mathPreview" style="border-radius: 6px; border: 1px solid #ddd; padding: 0.75rem; background: white; min-height: 44px; font-size: 1.1rem; display: flex; align-items: center; justify-content: center; overflow: auto;">
              (preview here)
            </div>
          </div>
        </div>
      </div>
      <div style="display: flex; border-bottom: 1px solid #e9ecef; background: white; overflow-x: auto;">`;
  
  Object.keys(symbolCategories).forEach((cat, idx) => {
    const isActive = idx === 0 ? 'background: #f3f4f6; border-bottom: 3px solid #3b82f6;' : '';
    htmlContent += `<button type="button" class="category-tab" data-category="${cat}" style="padding: 0.75rem 1rem; border: none; cursor: pointer; font-weight: 600; color: #6b7280; ${isActive} flex-shrink: 0; transition: all 0.2s;">${cat}</button>`;
  });
  
  htmlContent += `</div>
      <div style="flex: 1; overflow-y: auto; padding: 1.5rem; padding-top: 1rem;">
        <div id="symbolGrid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(60px, 1fr)); gap: 0.75rem;"></div>
      </div>
      <div style="background: #f8f9fa; padding: 1rem; border-top: 1px solid #e9ecef; display: flex; gap: 0.75rem; flex-wrap: wrap;">
        <button type="button" class="btn btn-primary" style="flex: 1; min-height: 44px; cursor: pointer;" onclick="insertMathEquation()">
          <i class="bi bi-check-circle me-1"></i>OK
        </button>
        <button type="button" class="btn btn-outline-secondary" style="flex: 1; min-height: 44px; cursor: pointer;" onclick="this.closest('[style*=position]').remove()">
          Cancel
        </button>
      </div>
    </div>
  `;
  
  modal.innerHTML = htmlContent;
  document.body.appendChild(modal);
  
  window.currentTextarea = textarea;
  
  function renderSymbols(category) {
    const grid = document.getElementById('symbolGrid');
    grid.innerHTML = '';
    
    (symbolCategories[category] || symbolCategories['Basic']).forEach(symbol => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.style.cssText = `background: white; border: 2px solid #e9ecef; border-radius: 6px; padding: 1rem; cursor: pointer; font-weight: 600; font-size: 1.2rem; color: #333; transition: all 0.2s; text-align: center;`;
      btn.textContent = symbol.char;
      btn.title = symbol.latex;
      btn.onmouseover = () => btn.style.cssText += 'background: #f0f0f0; border-color: #667eea;';
      btn.onmouseout = () => btn.style.cssText = `background: white; border: 2px solid #e9ecef; border-radius: 6px; padding: 1rem; cursor: pointer; font-weight: 600; font-size: 1.2rem; color: #333; transition: all 0.2s; text-align: center;`;
      btn.onclick = () => {
        const input = document.getElementById('latexInput');
        input.value += symbol.latex + ' ';
        input.focus();
        updatePreview();
      };
      grid.appendChild(btn);
    });
  }
  
  document.querySelectorAll('.category-tab').forEach(tab => {
    tab.onclick = () => {
      document.querySelectorAll('.category-tab').forEach(t => t.style.cssText = 'padding: 0.75rem 1rem; border: none; cursor: pointer; font-weight: 600; color: #333; flex-shrink: 0; transition: all 0.2s;');
      tab.style.cssText = 'padding: 0.75rem 1rem; border: none; cursor: pointer; font-weight: 600; color: #333; flex-shrink: 0; transition: all 0.2s; background: #f0f0f0; border-bottom: 3px solid #667eea;';
      renderSymbols(tab.dataset.category);
    };
  });
  
  function updatePreview() {
    const input = document.getElementById('latexInput');
    const preview = document.getElementById('mathPreview');
    preview.textContent = input.value || '(preview here)';
    if (window.renderMathInElement) {
      try {
        window.renderMathInElement(preview, {
          delimiters: [{left: '$$', right: '$$', display: true}, {left: '$', right: '$', display: false}],
          throwOnError: false
        });
      } catch(e) {}
    }
  }
  
  document.getElementById('latexInput').oninput = updatePreview;
  renderSymbols('Basic');
  modal.addEventListener('click', (e) => { if (e.target === modal) modal.remove(); });
}

function insertMathEquation() {
  const input = document.getElementById('latexInput');
  const latexCode = input.value.trim();
  
  if (!latexCode) { alert('Please enter or select LaTeX code'); return; }
  
  const equation = '$$' + latexCode + '$$';
  
  if (window.currentTextarea) {
    const start = window.currentTextarea.selectionStart;
    const end = window.currentTextarea.selectionEnd;
    const text = window.currentTextarea.value;
    
    window.currentTextarea.value = text.substring(0, start) + ' ' + equation + ' ' + text.substring(end);
    window.currentTextarea.focus();
    window.currentTextarea.dispatchEvent(new Event('input', { bubbles: true }));
  }
  
  document.querySelector('[style*="position: fixed"][style*="z-index: 9999"]')?.remove();
}

function updateQuestionCount(){
  const hdr = document.getElementById('questionCount');
  if (hdr) { hdr.textContent = document.querySelectorAll('.question-card').length; }
  // Update all question numbers
  document.querySelectorAll('.question-card').forEach((card, index) => {
    const header = card.querySelector('h4');
    if (header) {
      header.textContent = `Question #${index + 1}`;
    }
  });
}

function addQuestionAfter(btn){
  const currentCard = btn.closest('.question-card');
  const allCards = document.querySelectorAll('.question-card');
  let insertIndex = 0;
  for (let i = 0; i < allCards.length; i++) {
    if (allCards[i] === currentCard) {
      insertIndex = i + 1;
      break;
    }
  }
  // Add the new question to the DOM after this one
  const newCard = createNewQuestionCard();
  if (insertIndex < allCards.length) {
    allCards[insertIndex].parentNode.insertBefore(newCard, allCards[insertIndex]);
  } else {
    document.getElementById('questions').appendChild(newCard);
  }
  // Now that element is in DOM, add default options (qIndex already incremented)
  const newQIndex = qIndex - 1;
  addOption(newQIndex);
  addOption(newQIndex);
  updateQuestionCount();
  debounceSaveDraft();
}

function createNewQuestionCard(){
  const idx = qIndex;
  const wrap = document.createElement('div');
  wrap.className = 'question-card border rounded-3 p-3 bg-white shadow-sm';
  
  wrap.innerHTML = `
    <div class="d-flex justify-content-between align-items-center mb-2">
      <h4 class="h6 mb-0">Question #${idx + 1}</h4>
      <button type="button" class="btn btn-sm btn-outline-danger" onclick="removeQuestion(this)"><i class="bi bi-x"></i></button>
    </div>
    <label class="form-label">Question text (Type Sinhala + Click symbols to insert)</label>
    <textarea class="form-control question-text" name="questions[${idx}]" rows="3" required style="font-family: 'Noto Sans Sinhala', 'Segoe UI', sans-serif;"></textarea>
    <button type="button" class="btn btn-sm" style="margin-top: 0.5rem; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border: none; border-radius: 6px; padding: 0.4rem 0.75rem; font-weight: 600; font-size: 0.85rem;" onclick="const p = this.nextElementSibling; p.style.display = p.style.display === 'none' ? 'flex' : 'none';">
      <i class="bi bi-calculator-fill me-1"></i>Math Symbols <span style="font-size: 0.75rem;">▼</span>
    </button>
    <div class="math-symbols-palette" style="display: none; margin-top: 0.5rem; padding: 0.75rem; background: #f8f9fa; border-radius: 6px; border: 1px solid #e9ecef; flex-wrap: wrap; gap: 0.25rem;"></div>
    <small class="text-muted d-block mt-2">Type normally, then click symbols to insert at cursor position</small>
    <div class="mb-3">
      <label class="form-label">Marks</label>
      <input type="number" class="form-control" name="marks[${idx}]" min="1" value="1" required>
    </div>
    <div class="mb-3">
      <label class="form-label">
        <i class="bi bi-file-earmark-image me-1"></i>Add Image or PDF (Optional)
      </label>
      <input type="file" class="form-control" name="question_images[${idx}]" accept="image/png,image/jpeg,image/gif,image/webp,application/pdf">
      <input type="hidden" name="existing_images[${idx}]" value="">
      <small class="text-muted d-block mt-2">PNG, JPEG, GIF, WebP, or PDF (max 5MB)</small>
      <div id="img_preview_${idx}" style="margin-top: 1rem; display: none;">
        <img id="img_${idx}" style="max-width: 100%; max-height: 200px; border-radius: 6px; border: 1px solid #dee2e6;">
      </div>
      <div id="pdf_preview_${idx}" style="margin-top: 1rem; display: none;">
        <a id="pdf_link_${idx}" href="#" target="_blank" rel="noopener">View PDF</a>
        <embed id="pdf_embed_${idx}" type="application/pdf" style="width: 100%; height: 220px; border: 1px solid #dee2e6; border-radius: 6px; margin-top: 0.5rem;">
      </div>
    </div>
    <div class="mb-3">
      <label class="form-label">Options</label>
      <div class="d-flex flex-column gap-2" id="opts_${idx}"></div>
      <button type="button" class="btn btn-outline-primary btn-sm mt-2" onclick="addOption(${idx})"><i class="bi bi-plus"></i> Add option</button>
    </div>
    <div class="alert alert-warning small mb-0" role="alert">
      <i class="bi bi-exclamation-triangle-fill"></i> <strong>Important:</strong> You must select which option is correct.
    </div>
    <div style="padding-top: 1rem; border-top: 1px solid #dee2e6; display: flex; justify-content: flex-end; margin-top: 1rem;">
      <button type="button" class="btn btn-sm" style="background: #e8f5e9; color: #2e7d32; border: 2px solid #4caf50; border-radius: 6px; padding: 0.6rem 1rem; font-weight: 600;" onclick="addQuestionAfter(this)">
        <i class="bi bi-plus-circle me-1"></i>Add Question After This
      </button>
    </div>
  `;
  
  // Autosave on input
  const qText = wrap.querySelector('.question-text');
  const marksInput = wrap.querySelector('input[name="marks['+idx+']"]');
  const fileInput = wrap.querySelector('input[name="question_images['+idx+']"]');
  
  qText.addEventListener('input', debounceSaveDraft);
  marksInput.addEventListener('input', debounceSaveDraft);
  
  // Setup file preview
  fileInput.addEventListener('change', function(){
    const file = this.files[0];
    const existingInput = wrap.querySelector(`input[name="existing_images[${idx}]"]`);
    if (existingInput) existingInput.value = '';
    if (file) {
      const isPdf = file.type === 'application/pdf' || /\.pdf$/i.test(file.name || '');
      const url = URL.createObjectURL(file);
      showAttachmentPreview(idx, url, isPdf);
    } else {
      showAttachmentPreview(idx, '', false, true);
    }
  });
  
  // Setup math symbols palette
  const textarea = wrap.querySelector('.question-text');
  const palette = wrap.querySelector('.math-symbols-palette');
  
  // Define math symbols
  const mathSymbols = [
    {char: '+', val: '+'}, {char: '−', val: '−'}, {char: '×', val: '×'}, {char: '÷', val: '÷'},
    {char: '=', val: '='}, {char: '≠', val: '≠'}, {char: '±', val: '±'}, {char: '∓', val: '∓'},
    {char: '>', val: '>'}, {char: '<', val: '<'}, {char: '≥', val: '≥'}, {char: '≤', val: '≤'},
    {char: '≈', val: '≈'}, {char: '≡', val: '≡'}, {char: 'x²', val: '²'}, {char: 'x³', val: '³'},
    {char: 'x⁴', val: '⁴'}, {char: 'x⁵', val: '⁵'}, {char: 'xⁿ', val: 'ⁿ'}, {char: '√', val: '√'},
    {char: '∛', val: '∛'}, {char: '∜', val: '∜'}, {char: 'x₁', val: '₁'}, {char: 'x₂', val: '₂'},
    {char: 'x₃', val: '₃'}, {char: 'x₄', val: '₄'}, {char: 'x₅', val: '₅'}, {char: 'xₙ', val: 'ₙ'},
    {char: 'α', val: 'α'}, {char: 'β', val: 'β'}, {char: 'γ', val: 'γ'}, {char: 'δ', val: 'δ'},
    {char: 'π', val: 'π'}, {char: 'σ', val: 'σ'}, {char: 'θ', val: 'θ'}, {char: 'λ', val: 'λ'},
    {char: '∞', val: '∞'}, {char: '∑', val: '∑'}, {char: '∏', val: '∏'}, {char: '∫', val: '∫'},
    {char: '°', val: '°'}, {char: '∈', val: '∈'}, {char: '∉', val: '∉'}, {char: '∩', val: '∩'},
    {char: '∪', val: '∪'}, {char: '⊆', val: '⊆'}, {char: '⊇', val: '⊇'}, {char: '→', val: '→'},
    {char: '←', val: '←'}, {char: '⟹', val: '⟹'}, {char: '⇔', val: '⇔'}, {char: '⊥', val: '⊥'}
  ];
  
  mathSymbols.forEach(sym => {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.textContent = sym.char;
    btn.style.cssText = 'padding: 0.4rem 0.6rem; background: white; border: 1px solid #ccc; border-radius: 4px; cursor: pointer; font-size: 0.9rem; font-weight: 600; color: #667eea; transition: 0.2s;';
    btn.onmouseover = () => btn.style.background = '#667eea30';
    btn.onmouseout = () => btn.style.background = 'white';
    btn.onclick = () => {
      const start = textarea.selectionStart;
      const end = textarea.selectionEnd;
      const text = textarea.value;
      textarea.value = text.substring(0, start) + sym.val + text.substring(end);
      textarea.focus();
      textarea.setSelectionRange(start + sym.val.length, start + sym.val.length);
      textarea.dispatchEvent(new Event('input', { bubbles: true }));
    };
    palette.appendChild(btn);
  });
  
  qIndex++;
  return wrap;
}

function addQuestion(prefill){
  const wrap = document.createElement('div');
  wrap.className = 'question-card border rounded-3 p-3 bg-white shadow-sm';
  const idx = qIndex;
  
  wrap.innerHTML = `
    <div class="d-flex justify-content-between align-items-center mb-2">
      <h4 class="h6 mb-0">Question #${idx + 1}</h4>
      <button type="button" class="btn btn-sm btn-outline-danger" onclick="removeQuestion(this)"><i class="bi bi-x"></i></button>
    </div>
    <label class="form-label">Question text (Type Sinhala + Click symbols to insert)</label>
    <textarea class="form-control question-text" name="questions[${idx}]" rows="3" required style="font-family: 'Noto Sans Sinhala', 'Segoe UI', sans-serif;"></textarea>
    <button type="button" class="btn btn-sm" style="margin-top: 0.5rem; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border: none; border-radius: 6px; padding: 0.4rem 0.75rem; font-weight: 600; font-size: 0.85rem;" onclick="const p = this.nextElementSibling; p.style.display = p.style.display === 'none' ? 'flex' : 'none';">
      <i class="bi bi-calculator-fill me-1"></i>Math Symbols <span style="font-size: 0.75rem;">▼</span>
    </button>
    <div class="math-symbols-palette" style="display: none; margin-top: 0.5rem; padding: 0.75rem; background: #f8f9fa; border-radius: 6px; border: 1px solid #e9ecef; flex-wrap: wrap; gap: 0.25rem;"></div>
    <small class="text-muted d-block mt-2">Type normally, then click symbols to insert at cursor position</small>
    <div class="mb-3">
      <label class="form-label">Marks</label>
      <input type="number" class="form-control" name="marks[${idx}]" min="1" value="1" required>
    </div>
    <div class="mb-3">
      <label class="form-label">
        <i class="bi bi-file-earmark-image me-1"></i>Add Image or PDF (Optional)
      </label>
      <input type="file" class="form-control" name="question_images[${idx}]" accept="image/png,image/jpeg,image/gif,image/webp,application/pdf">
      <input type="hidden" name="existing_images[${idx}]" value="">
      <small class="text-muted d-block mt-2">PNG, JPEG, GIF, WebP, or PDF (max 5MB)</small>
      <div id="img_preview_${idx}" style="margin-top: 1rem; display: none;">
        <img id="img_${idx}" style="max-width: 100%; max-height: 200px; border-radius: 6px; border: 1px solid #dee2e6;">
      </div>
      <div id="pdf_preview_${idx}" style="margin-top: 1rem; display: none;">
        <a id="pdf_link_${idx}" href="#" target="_blank" rel="noopener">View PDF</a>
        <embed id="pdf_embed_${idx}" type="application/pdf" style="width: 100%; height: 220px; border: 1px solid #dee2e6; border-radius: 6px; margin-top: 0.5rem;">
      </div>
    </div>
    <div class="mb-3">
      <label class="form-label">Options</label>
      <div class="d-flex flex-column gap-2" id="opts_${idx}"></div>
      <button type="button" class="btn btn-outline-primary btn-sm mt-2" onclick="addOption(${idx})"><i class="bi bi-plus"></i> Add option</button>
    </div>
    <div class="alert alert-warning small mb-0" role="alert">
      <i class="bi bi-exclamation-triangle-fill"></i> <strong>Important:</strong> You must select which option is correct.
    </div>
    <div style="padding-top: 1rem; border-top: 1px solid #dee2e6; display: flex; justify-content: flex-end; margin-top: 1rem;">
      <button type="button" class="btn btn-sm" style="background: #e8f5e9; color: #2e7d32; border: 2px solid #4caf50; border-radius: 6px; padding: 0.6rem 1rem; font-weight: 600;" onclick="addQuestionAfter(this)">
        <i class="bi bi-plus-circle me-1"></i>Add Question After This
      </button>
    </div>
  `;
  document.getElementById('questions').appendChild(wrap);
  qIndex++;
  updateQuestionCount();

  // Prefill content
  if (prefill) {
    const textarea = wrap.querySelector('textarea');
    textarea.value = prefill.question_text || '';
    wrap.querySelector('input[name="marks['+idx+']"]').value = prefill.marks || 1;
    const opts = prefill.options || [];
    if (opts.length === 0) { addOption(idx); addOption(idx); }
    opts.forEach((o, j) => addOption(idx, o, j));
    const existingInput = wrap.querySelector(`input[name="existing_images[${idx}]"]`);
    if (existingInput && prefill.image_path) {
      existingInput.value = prefill.image_path;
      const isPdf = /\.pdf$/i.test(prefill.image_path);
      showAttachmentPreview(idx, prefill.image_path, isPdf);
    }
    
    // Math preview
    const preview = wrap.querySelector('.math-preview');
    if (textarea.value.trim() && preview) {
      preview.innerHTML = textarea.value;
      preview.style.display = 'block';
      if (window.renderMathInElement) {
        try {
          window.renderMathInElement(preview, {
            delimiters: [{left: '$$', right: '$$', display: true}, {left: '$', right: '$', display: false}],
            throwOnError: false
          });
        } catch(e) {}
      }
    }
  } else {
    addOption(idx); addOption(idx);
  }
  
  // Autosave on input
  const qText = wrap.querySelector('.question-text');
  const marksInput = wrap.querySelector('input[name="marks['+idx+']"]');
  qText.addEventListener('input', debounceSaveDraft);
  marksInput.addEventListener('input', debounceSaveDraft);

  // Setup math symbols palette
  const textarea = wrap.querySelector('.question-text');
  const palette = wrap.querySelector('.math-symbols-palette');
  
  // Define math symbols that can be clicked to insert
  const mathSymbols = [
    // Basic Arithmetic
    {char: '+', val: '+'},
    {char: '−', val: '−'},
    {char: '×', val: '×'},
    {char: '÷', val: '÷'},
    {char: '=', val: '='},
    {char: '≠', val: '≠'},
    {char: '±', val: '±'},
    {char: '∓', val: '∓'},
    
    // Comparison
    {char: '>', val: '>'},
    {char: '<', val: '<'},
    {char: '≥', val: '≥'},
    {char: '≤', val: '≤'},
    {char: '≈', val: '≈'},
    {char: '≡', val: '≡'},
    
    // Exponents & Roots
    {char: 'x²', val: '²'},
    {char: 'x³', val: '³'},
    {char: 'x⁴', val: '⁴'},
    {char: 'x⁵', val: '⁵'},
    {char: 'xⁿ', val: 'ⁿ'},
    {char: '√', val: '√'},
    {char: '∛', val: '∛'},
    {char: '∜', val: '∜'},
    
    // Subscripts
    {char: 'x₁', val: '₁'},
    {char: 'x₂', val: '₂'},
    {char: 'x₃', val: '₃'},
    {char: 'x₄', val: '₄'},
    {char: 'x₅', val: '₅'},
    {char: 'xₙ', val: 'ₙ'},
    
    // Greek Letters - Lowercase
    {char: 'α', val: 'α'},
    {char: 'β', val: 'β'},
    {char: 'γ', val: 'γ'},
    {char: 'δ', val: 'δ'},
    {char: 'ε', val: 'ε'},
    {char: 'ζ', val: 'ζ'},
    {char: 'η', val: 'η'},
    {char: 'θ', val: 'θ'},
    {char: 'ι', val: 'ι'},
    {char: 'κ', val: 'κ'},
    {char: 'λ', val: 'λ'},
    {char: 'μ', val: 'μ'},
    {char: 'ν', val: 'ν'},
    {char: 'ξ', val: 'ξ'},
    {char: 'π', val: 'π'},
    {char: 'ρ', val: 'ρ'},
    {char: 'σ', val: 'σ'},
    {char: 'τ', val: 'τ'},
    {char: 'υ', val: 'υ'},
    {char: 'φ', val: 'φ'},
    {char: 'χ', val: 'χ'},
    {char: 'ψ', val: 'ψ'},
    {char: 'ω', val: 'ω'},
    
    // Greek Letters - Uppercase
    {char: 'Α', val: 'Α'},
    {char: 'Β', val: 'Β'},
    {char: 'Γ', val: 'Γ'},
    {char: 'Δ', val: 'Δ'},
    {char: 'Ε', val: 'Ε'},
    {char: 'Ζ', val: 'Ζ'},
    {char: 'Η', val: 'Η'},
    {char: 'Θ', val: 'Θ'},
    {char: 'Κ', val: 'Κ'},
    {char: 'Λ', val: 'Λ'},
    {char: 'Μ', val: 'Μ'},
    {char: 'Ν', val: 'Ν'},
    {char: 'Ξ', val: 'Ξ'},
    {char: 'Π', val: 'Π'},
    {char: 'Σ', val: 'Σ'},
    {char: 'Τ', val: 'Τ'},
    {char: 'Υ', val: 'Υ'},
    {char: 'Φ', val: 'Φ'},
    {char: 'Χ', val: 'Χ'},
    {char: 'Ψ', val: 'Ψ'},
    {char: 'Ω', val: 'Ω'},
    
    // Calculus & Analysis
    {char: '∫', val: '∫'},
    {char: '∬', val: '∬'},
    {char: '∭', val: '∭'},
    {char: '∮', val: '∮'},
    {char: '∑', val: '∑'},
    {char: '∏', val: '∏'},
    {char: '∞', val: '∞'},
    {char: '∂', val: '∂'},
    {char: '∇', val: '∇'},
    {char: '°', val: '°'},
    {char: '′', val: '′'},
    {char: '″', val: '″'},
    
    // Set Theory & Logic
    {char: '∈', val: '∈'},
    {char: '∉', val: '∉'},
    {char: '⊂', val: '⊂'},
    {char: '⊃', val: '⊃'},
    {char: '⊆', val: '⊆'},
    {char: '⊇', val: '⊇'},
    {char: '∩', val: '∩'},
    {char: '∪', val: '∪'},
    {char: '∅', val: '∅'},
    {char: '∀', val: '∀'},
    {char: '∃', val: '∃'},
    {char: '¬', val: '¬'},
    {char: '∧', val: '∧'},
    {char: '∨', val: '∨'},
    
    // Arrows
    {char: '→', val: '→'},
    {char: '←', val: '←'},
    {char: '↑', val: '↑'},
    {char: '↓', val: '↓'},
    {char: '↔', val: '↔'},
    {char: '↕', val: '↕'},
    {char: '⇒', val: '⇒'},
    {char: '⇐', val: '⇐'},
    {char: '⇔', val: '⇔'},
    {char: '⟹', val: '⟹'},
    {char: '⟸', val: '⟸'},
    
    // Miscellaneous
    {char: '°', val: '°'},
    {char: '′', val: '′'},
    {char: '∴', val: '∴'},
    {char: '∵', val: '∵'},
    {char: '⊥', val: '⊥'},
    {char: '∥', val: '∥'},
    {char: '⊙', val: '⊙'},
    {char: '⊕', val: '⊕'},
    {char: '⊗', val: '⊗'},
    {char: '⊄', val: '⊄'},
  ];
  
  // Populate the symbol palette
  mathSymbols.forEach(symbol => {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.textContent = symbol.char;
    btn.title = 'Insert ' + symbol.char;
    btn.style.cssText = 'padding: 0.4rem 0.6rem; background: white; border: 1px solid #dee2e6; border-radius: 4px; cursor: pointer; font-size: 1rem; min-width: 36px; transition: all 0.15s;';
    btn.onmouseover = () => btn.style.background = '#e9ecef';
    btn.onmouseout = () => btn.style.background = 'white';
    btn.onclick = () => {
      const start = textarea.selectionStart;
      const end = textarea.selectionEnd;
      const text = textarea.value;
      const before = text.substring(0, start);
      const after = text.substring(end);
      textarea.value = before + symbol.val + after;
      textarea.selectionStart = textarea.selectionEnd = start + symbol.val.length;
      textarea.focus();
      textarea.dispatchEvent(new Event('input'));
    };
    palette.appendChild(btn);
  });
  
  debounceSaveDraft();
}

function removeQuestion(btn){
  btn.closest('.question-card').remove();
  updateQuestionCount();
  debounceSaveDraft();
}

const optionSymbols = ['+', '-', '×', '÷', '=', '≠', '≤', '≥', '√', '^', '²', '³', 'π', 'θ', 'α', 'β'];

function insertSymbolIntoInput(input, symbol){
  if (!input) return;
  const start = input.selectionStart ?? input.value.length;
  const end = input.selectionEnd ?? input.value.length;
  const text = input.value || '';
  input.value = text.substring(0, start) + symbol + text.substring(end);
  input.focus();
  const pos = start + symbol.length;
  if (input.setSelectionRange) { input.setSelectionRange(pos, pos); }
  input.dispatchEvent(new Event('input', { bubbles: true }));
}

function showOptionAttachmentPreview(qIdx, optIdx, url, isPdf, clearOnly){
  const img = document.getElementById(`opt_img_${qIdx}_${optIdx}`);
  const imgWrap = document.getElementById(`opt_img_wrap_${qIdx}_${optIdx}`);
  const pdfWrap = document.getElementById(`opt_pdf_wrap_${qIdx}_${optIdx}`);
  const pdfLink = document.getElementById(`opt_pdf_link_${qIdx}_${optIdx}`);
  const pdfEmbed = document.getElementById(`opt_pdf_embed_${qIdx}_${optIdx}`);
  if (!imgWrap || !pdfWrap) return;
  if (clearOnly || !url) {
    imgWrap.style.display = 'none';
    pdfWrap.style.display = 'none';
    if (img) img.removeAttribute('src');
    if (pdfEmbed) pdfEmbed.removeAttribute('src');
    if (pdfLink) pdfLink.removeAttribute('href');
    return;
  }
  if (isPdf) {
    imgWrap.style.display = 'none';
    if (pdfLink) pdfLink.href = url;
    if (pdfEmbed) pdfEmbed.src = url;
    pdfWrap.style.display = 'block';
  } else {
    if (img) img.src = url;
    imgWrap.style.display = 'block';
    pdfWrap.style.display = 'none';
  }
}

function addOption(i, prefill, optIndex){
  const oWrap = document.getElementById('opts_' + i);
  if (!oWrap) return; // Element not in DOM yet, skip
  const count = (typeof optIndex === 'number') ? optIndex : oWrap.querySelectorAll('.input-group').length;
  const div = document.createElement('div');
  div.className = 'option-wrap';
  div.style.cssText = 'display: flex; flex-direction: column; gap: 0.35rem;';
  div.innerHTML = `
    <div class="input-group align-items-center">
      <input type="radio" class="form-check-input ms-2" name="correct[${i}]" value="${count}" id="correct_${i}_${count}">
      <input type="text" class="form-control" name="options[${i}][${count}]" placeholder="Option text" required>
      <select class="form-select form-select-sm" style="max-width: 110px;">
        <option value="">Symbols</option>
        ${optionSymbols.map(s => `<option value="${s}">${s}</option>`).join('')}
      </select>
      <input type="file" class="form-control form-control-sm" name="option_attachments[${i}][${count}]" accept="image/png,image/jpeg,image/gif,image/webp,application/pdf" style="max-width: 220px;">
      <input type="hidden" name="existing_option_attachments[${i}][${count}]" value="">
      <button class="btn btn-outline-danger" type="button" onclick="this.closest('.option-wrap').remove()">Remove</button>
    </div>
    <div id="opt_img_wrap_${i}_${count}" style="display: none; margin-left: 2.5rem;">
      <img id="opt_img_${i}_${count}" style="max-width: 100%; max-height: 160px; border-radius: 6px; border: 1px solid #dee2e6;">
    </div>
    <div id="opt_pdf_wrap_${i}_${count}" style="display: none; margin-left: 2.5rem;">
      <a id="opt_pdf_link_${i}_${count}" href="#" target="_blank" rel="noopener">View PDF</a>
      <embed id="opt_pdf_embed_${i}_${count}" type="application/pdf" style="width: 100%; height: 200px; border: 1px solid #dee2e6; border-radius: 6px; margin-top: 0.5rem;">
    </div>
  `;
  oWrap.appendChild(div);
  if (prefill) {
    div.querySelector('input[type=text]').value = prefill.option_text;
    if (prefill.is_correct) { div.querySelector('input[type=radio]').checked = true; }
    const existingOpt = div.querySelector('input[type="hidden"]');
    if (existingOpt && prefill.attachment_path) {
      existingOpt.value = prefill.attachment_path;
      const isPdf = /\.pdf$/i.test(prefill.attachment_path);
      showOptionAttachmentPreview(i, count, prefill.attachment_path, isPdf);
    }
  }

  const fileInput = div.querySelector('input[type="file"]');
  const symbolSelect = div.querySelector('select');
  if (symbolSelect) {
    symbolSelect.addEventListener('change', () => {
      if (symbolSelect.value) {
        insertSymbolIntoInput(div.querySelector('input[type=text]'), symbolSelect.value);
        symbolSelect.selectedIndex = 0;
      }
    });
  }
  if (fileInput) {
    fileInput.addEventListener('change', () => {
      const file = fileInput.files[0];
      const existingOpt = div.querySelector('input[type="hidden"]');
      if (existingOpt) existingOpt.value = '';
      if (file) {
        const isPdf = file.type === 'application/pdf' || /\.pdf$/i.test(file.name || '');
        const url = URL.createObjectURL(file);
        showOptionAttachmentPreview(i, count, url, isPdf);
      } else {
        showOptionAttachmentPreview(i, count, '', false, true);
      }
    });
  }

  // Autosave on change
  const radio = div.querySelector('input[type="radio"]');
  const textInput = div.querySelector('input[type="text"]');
  radio.addEventListener('change', debounceSaveDraft);
  textInput.addEventListener('input', debounceSaveDraft);
}

function showAttachmentPreview(idx, url, isPdf, clearOnly){
  const imgPreview = document.getElementById('img_preview_' + idx);
  const img = document.getElementById('img_' + idx);
  const pdfPreview = document.getElementById('pdf_preview_' + idx);
  const pdfLink = document.getElementById('pdf_link_' + idx);
  const pdfEmbed = document.getElementById('pdf_embed_' + idx);

  if (!imgPreview || !pdfPreview) return;

  if (clearOnly || !url) {
    imgPreview.style.display = 'none';
    pdfPreview.style.display = 'none';
    if (img) img.removeAttribute('src');
    if (pdfEmbed) pdfEmbed.removeAttribute('src');
    if (pdfLink) pdfLink.removeAttribute('href');
    return;
  }

  if (isPdf) {
    imgPreview.style.display = 'none';
    if (pdfLink) pdfLink.href = url;
    if (pdfEmbed) pdfEmbed.src = url;
    pdfPreview.style.display = 'block';
  } else {
    if (img) img.src = url;
    imgPreview.style.display = 'block';
    pdfPreview.style.display = 'none';
  }
}


document.addEventListener('DOMContentLoaded', () => {
  // Prefill paper fields
  document.getElementById('title').value = paperData.title || '';
  document.getElementById('fee_cents').value = paperData.fee_cents || 0;
  document.getElementById('time_limit_minutes').value = Math.max(1, Math.round((paperData.time_limit_seconds||60)/60));
  if (paperData.is_published) { document.getElementById('publishNow').checked = true; }

  if (Array.isArray(questionsData) && questionsData.length) {
    questionsData.forEach(q => addQuestion(q));
  } else {
    addQuestion();
  }

  // Add autosave status element and try restoring draft
  const form = document.getElementById('editForm');
  if (form) {
    const status = document.createElement('p');
    status.id = 'autosaveStatus';
    status.className = 'small text-muted mt-2';
    status.textContent = 'Draft not saved yet';
    form.appendChild(status);
  }
  loadDraft();

  // Add file input change handlers for image preview
  document.addEventListener('change', function(e) {
    if(e.target.name && e.target.name.startsWith('question_images')) {
      const file = e.target.files[0];
      if(file){
        const match = e.target.name.match(/\[(\d+)\]/);
        const index = match ? match[1] : null;
        if(index){
          const isPdf = file.type === 'application/pdf' || /\.pdf$/i.test(file.name || '');
          const url = URL.createObjectURL(file);
          showAttachmentPreview(index, url, isPdf);
          const existingInput = document.querySelector(`input[name="existing_images[${index}]"]`);
          if (existingInput) existingInput.value = '';
        }
      } else {
        const match = e.target.name.match(/\[(\d+)\]/);
        const index = match ? match[1] : null;
        if (index) { showAttachmentPreview(index, '', false, true); }
      }
    }
  });

  // Validate correct answers before submit
  document.getElementById('editForm').addEventListener('submit', (e) => {
    const cards = document.querySelectorAll('.question-card');
    let hasError = false;
    cards.forEach((card, idx) => {
      const radios = card.querySelectorAll(`input[name="correct[${idx}]"]`);
      const isChecked = Array.from(radios).some(r => r.checked);
      if (!isChecked && radios.length > 0) {
        hasError = true;
        const alertBox = card.querySelector('.alert');
        if (alertBox) {
          alertBox.classList.remove('alert-warning');
          alertBox.classList.add('alert-danger');
          alertBox.innerHTML = '<i class="bi bi-exclamation-triangle-fill"></i> <strong>ERROR:</strong> Select the correct option.';
        }
      }
    });
    if (hasError) {
      e.preventDefault();
      alert('Please select the correct answer for every question.');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
    else { clearDraft(); }
  });
  
  // Periodic autosave every 30s while tab is visible (local + backend)
  let autosaveEnabled = true;
  async function autosaveToServer() {
    if (document.visibilityState !== 'visible' || !autosaveEnabled) return;
    try {
      const fd = new FormData();
      fd.append('title', document.getElementById('title')?.value || '');
      fd.append('fee_cents', document.getElementById('fee_cents')?.value || '0');
      fd.append('time_limit_minutes', document.getElementById('time_limit_minutes')?.value || '1');
      fd.append('_csrf', document.querySelector('input[name="_csrf"]')?.value || '');
      fd.append('autosave', '1');
      const res = await fetch(window.location.href, { method: 'POST', body: fd });
      const data = await res.json().catch(() => null);
      if (data && typeof data.csrf === 'string') {
        const csrfField = document.querySelector('input[name="_csrf"]');
        if (csrfField) csrfField.value = data.csrf;
      }
      const status = document.getElementById('autosaveStatus');
      if (status && data && data.ok) status.textContent = 'Autosaved to server at ' + new Date().toLocaleTimeString();
      if (res.status === 400 && data && /Invalid CSRF/i.test(data.error || '')) {
        // Retry once after token refresh
        // Replace CSRF in form-data with refreshed token
        const newCsrf = (document.querySelector('input[name="_csrf"]')?.value || '');
        if (newCsrf) { fd.set('_csrf', newCsrf); }
        const retry = await fetch(window.location.href, { method: 'POST', body: fd });
        const rdata = await retry.json().catch(() => null);
        if (rdata && typeof rdata.csrf === 'string') {
          const csrfField = document.querySelector('input[name="_csrf"]');
          if (csrfField) csrfField.value = rdata.csrf;
        }
        const status2 = document.getElementById('autosaveStatus');
        if (status2 && rdata && rdata.ok) status2.textContent = 'Autosaved to server at ' + new Date().toLocaleTimeString();
      }
    } catch (e) { /* ignore */ }
  }
  const autosaveTimer = setInterval(() => { if (document.visibilityState === 'visible') { saveDraft(); autosaveToServer(); } }, 60000);
  // Suppress autosave during manual submit
  document.getElementById('editForm').addEventListener('submit', () => { autosaveEnabled = false; clearInterval(autosaveTimer); });
});
</script>
<?php render_footer(); ?>

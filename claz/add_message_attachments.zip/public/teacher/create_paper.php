<?php
header('Content-Type: text/html; charset=UTF-8');
mb_internal_encoding('UTF-8');
mb_http_output('UTF-8');
require_once __DIR__ . '/../../src/config.php';
require_once __DIR__ . '/../../src/csrf.php';
require_once __DIR__ . '/../../src/layout.php';
require_login();
$user = current_user();
if ($user['user_type'] !== 'teacher') { http_response_code(403); echo 'Forbidden'; exit; }

$errors = [];
$success = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $isAutosave = (($_POST['autosave'] ?? '') === '1');
  if (!csrf_verify()) { $errors[] = 'Invalid CSRF token'; }
  $title = trim($_POST['title'] ?? '');
  $fee = (int)($_POST['fee_cents'] ?? 0);
  $timeLimit = (int)($_POST['time_limit_minutes'] ?? 0) * 60;
  $questions = $_POST['questions'] ?? [];
  $options = $_POST['options'] ?? [];
  $correct = $_POST['correct'] ?? [];
  $publish = isset($_POST['publish']) ? 1 : 0;
  $effectivePublish = $isAutosave ? 0 : $publish; // never publish via autosave
  $draftPaperId = (int)($_POST['draft_paper_id'] ?? 0);

    if (!$title || $timeLimit <= 0) { $errors[] = 'Title and time limit required.'; }
    if (empty($questions)) { $errors[] = 'At least one question required.'; }

    if (!$errors) {
      $pdo = db();
      $pdo->beginTransaction();
      try {
            if ($isAutosave && $draftPaperId > 0) {
          // Update existing draft owned by this teacher
          $check = $pdo->prepare('SELECT id FROM papers WHERE id=? AND teacher_id=?');
          $check->execute([$draftPaperId, $user['id']]);
          $row = $check->fetch();
          if ($row) {
                    // Do not change publish state in autosave updates
                    $u = $pdo->prepare('UPDATE papers SET title=?, fee_cents=?, time_limit_seconds=? WHERE id=? AND teacher_id=?');
                    $u->execute([$title, $fee, $timeLimit, $draftPaperId, $user['id']]);

            $pdo->prepare('DELETE FROM questions WHERE paper_id=?')->execute([$draftPaperId]);

            $positionsIn = $_POST['insert_position'] ?? [];
            $questionsToInsert = [];

            foreach ($questions as $i => $qText) {
              $qText = trim($qText);
              if ($qText === '') { continue; }
              $marks = (int)($_POST['marks'][$i] ?? 1);
              if ($marks < 1) $marks = 1;

              $imagePath = null;
              if (isset($_FILES['question_images']) && isset($_FILES['question_images']['tmp_name'][$i]) && $_FILES['question_images']['tmp_name'][$i]) {
                $file = $_FILES['question_images'];
                $tmpFile = $file['tmp_name'][$i];
                $fileName = $file['name'][$i];
                $fileType = pathinfo($fileName, PATHINFO_EXTENSION);
                if (in_array(strtolower($fileType), ['jpg', 'jpeg', 'png', 'gif', 'webp', 'pdf'])) {
                  $newFileName = 'q_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $fileType;
                  $uploadDir = __DIR__ . '/uploads/questions/';
                  if (!is_dir($uploadDir)) @mkdir($uploadDir, 0755, true);
                  $destFile = $uploadDir . $newFileName;
                  if (move_uploaded_file($tmpFile, $destFile)) {
                    $imagePath = 'uploads/questions/' . $newFileName;
                  }
                }
              }

              $optFiles = $_FILES['option_attachments'] ?? null;
              $optsForQuestion = [];
              $optTexts = $options[$i] ?? [];
              foreach ($optTexts as $j => $optText) {
                $optText = (string)$optText;
                $optAttachmentPath = null;
                if ($optFiles && isset($optFiles['tmp_name'][$i][$j]) && $optFiles['tmp_name'][$i][$j]) {
                  $tmpFile = $optFiles['tmp_name'][$i][$j];
                  $fileName = $optFiles['name'][$i][$j] ?? '';
                  $fileType = pathinfo($fileName, PATHINFO_EXTENSION);
                  if (in_array(strtolower($fileType), ['jpg', 'jpeg', 'png', 'gif', 'webp', 'pdf'])) {
                    $newFileName = 'opt_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $fileType;
                    $uploadDir = __DIR__ . '/uploads/options/';
                    if (!is_dir($uploadDir)) @mkdir($uploadDir, 0755, true);
                    $destFile = $uploadDir . $newFileName;
                    if (move_uploaded_file($tmpFile, $destFile)) {
                      $optAttachmentPath = 'uploads/options/' . $newFileName;
                    }
                  }
                }
                $optsForQuestion[] = ['text' => $optText, 'attachment' => $optAttachmentPath, 'index' => $j];
              }

              $requestedPos = isset($positionsIn[$i]) ? (int)$positionsIn[$i] : count($questionsToInsert) + 1;
              $questionsToInsert[] = [
                'text' => $qText,
                'marks' => $marks,
                'position' => $requestedPos,
                'image' => $imagePath,
                'options' => $optsForQuestion,
                'correct' => $correct[$i] ?? -1
              ];
            }

            usort($questionsToInsert, function($a, $b) {
              return $a['position'] <=> $b['position'];
            });

            $qIns = $pdo->prepare('INSERT INTO questions (paper_id,question_text,marks,position,image_path) VALUES (?,?,?,?,?)');
            $oIns = $pdo->prepare('INSERT INTO answer_options (question_id,option_text,is_correct,attachment_path) VALUES (?,?,?,?)');
            foreach ($questionsToInsert as $idx => $q) {
              $qIns->execute([$draftPaperId, $q['text'], $q['marks'], $idx + 1, $q['image']]);
              $newQid = $pdo->lastInsertId();
              foreach ($q['options'] as $j => $optText) {
                $oIns->execute([
                  $newQid,
                  trim((string)$optText['text']),
                  ((string)$q['correct'] === (string)$optText['index']) ? 1 : 0,
                  $optText['attachment']
                ]);
              }
            }
            $paperId = $draftPaperId;
          } else {
            $paperId = 0;
          }
        } else {
          // Insert new paper
                $stmt = $pdo->prepare('INSERT INTO papers (teacher_id,title,fee_cents,time_limit_seconds,is_published) VALUES (?,?,?,?,?)');
                $stmt->execute([$user['id'], $title, $fee, $timeLimit, $effectivePublish]);
          $paperId = $pdo->lastInsertId();
          $positionsIn = $_POST['insert_position'] ?? [];
          $questionsToInsert = [];

          foreach ($questions as $i => $qText) {
            $qText = trim($qText);
            if ($qText === '') { continue; }
            $marks = (int)($_POST['marks'][$i] ?? 1);
            if ($marks < 1) $marks = 1;
            $imagePath = null;
            if (isset($_FILES['question_images']) && isset($_FILES['question_images']['tmp_name'][$i]) && $_FILES['question_images']['tmp_name'][$i]) {
              $file = $_FILES['question_images'];
              $tmpFile = $file['tmp_name'][$i];
              $fileName = $file['name'][$i];
              $fileType = pathinfo($fileName, PATHINFO_EXTENSION);
              if (in_array(strtolower($fileType), ['jpg', 'jpeg', 'png', 'gif', 'webp', 'pdf'])) {
                $newFileName = 'q_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $fileType;
                $uploadDir = __DIR__ . '/uploads/questions/';
                if (!is_dir($uploadDir)) @mkdir($uploadDir, 0755, true);
                $destFile = $uploadDir . $newFileName;
                if (move_uploaded_file($tmpFile, $destFile)) {
                  $imagePath = 'uploads/questions/' . $newFileName;
                }
              }
            }
            $optFiles = $_FILES['option_attachments'] ?? null;
            $optsForQuestion = [];
            $optTexts = $options[$i] ?? [];
            foreach ($optTexts as $j => $optText) {
              $optText = (string)$optText;
              $optAttachmentPath = null;
              if ($optFiles && isset($optFiles['tmp_name'][$i][$j]) && $optFiles['tmp_name'][$i][$j]) {
                $tmpFile = $optFiles['tmp_name'][$i][$j];
                $fileName = $optFiles['name'][$i][$j] ?? '';
                $fileType = pathinfo($fileName, PATHINFO_EXTENSION);
                if (in_array(strtolower($fileType), ['jpg', 'jpeg', 'png', 'gif', 'webp', 'pdf'])) {
                  $newFileName = 'opt_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $fileType;
                  $uploadDir = __DIR__ . '/uploads/options/';
                  if (!is_dir($uploadDir)) @mkdir($uploadDir, 0755, true);
                  $destFile = $uploadDir . $newFileName;
                  if (move_uploaded_file($tmpFile, $destFile)) {
                    $optAttachmentPath = 'uploads/options/' . $newFileName;
                  }
                }
              }
              $optsForQuestion[] = ['text' => $optText, 'attachment' => $optAttachmentPath, 'index' => $j];
            }

            $requestedPos = isset($positionsIn[$i]) ? (int)$positionsIn[$i] : count($questionsToInsert) + 1;
            $questionsToInsert[] = [
              'text' => $qText,
              'marks' => $marks,
              'position' => $requestedPos,
              'image' => $imagePath,
              'options' => $optsForQuestion,
              'correct' => $correct[$i] ?? -1
            ];
          }

          usort($questionsToInsert, function($a, $b) {
            return $a['position'] <=> $b['position'];
          });

          $stmtQ = $pdo->prepare('INSERT INTO questions (paper_id,question_text,marks,position,image_path) VALUES (?,?,?,?,?)');
          $stmtO = $pdo->prepare('INSERT INTO answer_options (question_id,option_text,is_correct,attachment_path) VALUES (?,?,?,?)');
          foreach ($questionsToInsert as $idx => $q) {
            $stmtQ->execute([$paperId, $q['text'], $q['marks'], $idx + 1, $q['image']]);
            $questionId = $pdo->lastInsertId();
            foreach ($q['options'] as $j => $optText) {
              $stmtO->execute([
                $questionId,
                trim((string)$optText['text']),
                ((string)$q['correct'] === (string)$optText['index']) ? 1 : 0,
                $optText['attachment']
              ]);
            }
          }
        }
        $pdo->commit();

        if ($isAutosave) {
          header('Content-Type: application/json');
          echo json_encode(['ok' => true, 'paper_id' => (int)$paperId, 'csrf' => csrf_token()]);
          exit;
        } else {
          $success = 'Paper created (ID ' . $paperId . ').';
        }
      } catch (Exception $e) {
        $pdo->rollBack();
        if ($isAutosave) {
          header('Content-Type: application/json');
          http_response_code(500);
          echo json_encode(['ok' => false, 'error' => $e->getMessage(), 'csrf' => csrf_token()]);
          exit;
        } else {
          $errors[] = 'Error: ' . $e->getMessage();
        }
      }
    } else if ($isAutosave) {
      header('Content-Type: application/json');
      http_response_code(400);
      echo json_encode(['ok' => false, 'error' => implode('\n', $errors), 'csrf' => csrf_token()]);
      exit;
    }
}
render_header('Create Paper');
?>

<!-- Load jQuery first for MathQuill -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<!-- MathQuill CSS & JS for visual math editor -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/mathquill/0.10.1/mathquill.min.css" crossorigin="anonymous" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/mathquill/0.10.1/mathquill.min.js" crossorigin="anonymous"></script>

<!-- Load KaTeX for math rendering -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.css" />
<script src="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/contrib/auto-render.min.js"></script>

<script>
  // Initialize KaTeX rendering when script loads
  function renderMath() {
    if (window.renderMathInElement) {
      try {
        window.renderMathInElement(document.body, {
          delimiters: [
            {left: '$$', right: '$$', display: true},
            {left: '$', right: '$', display: false},
            {left: '\\[', right: '\\]', display: true},
            {left: '\\(', right: '\\)', display: false}
          ],
          throwOnError: false
        });
      } catch(err) {
        console.log('KaTeX render error:', err.message);
      }
    }
  }
  
  // Render when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', renderMath);
  } else {
    renderMath();
  }
</script>

<!-- Hero Section -->
<section style="background: white; border-radius: 12px; padding: 3rem; margin-bottom: 3rem; position: relative; overflow: hidden; border-left: 4px solid #3b82f6;">
  <div style="position: absolute; top: 0; right: 0; font-size: 8rem; opacity: 0.05; color: #3b82f6;">
    <i class="bi bi-pencil-square"></i>
  </div>
  <div class="position-relative">
    <h1 class="mb-2" style="font-size: 2.5rem; font-weight: 700; color: #1f2937;">
      <i class="bi bi-pencil-square me-2" style="color: #3b82f6;"></i>Create New Paper
    </h1>
    <p style="color: #6b7280; font-size: 1.1rem; margin: 0;">Build MCQ papers and publish to your students</p>
  </div>
</section>

<!-- Info Cards -->
<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 1.5rem; margin-bottom: 3rem;">
  <!-- Status Card -->
  <div style="background: white; border-radius: 12px; padding: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.06); border: 1px solid #e5e7eb; border-bottom: 3px solid #9ca3af;">
    <div style="display: flex; align-items: flex-start; justify-content: space-between; gap: 1rem;">
      <div style="flex: 1;">
        <p style="margin: 0 0 0.5rem 0; color: #6b7280; font-size: 0.9rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em;">Status</p>
        <p style="margin: 0; font-weight: 700; color: #6b7280; font-size: 1.8rem;">Draft</p>
        <p style="margin: 0.5rem 0 0 0; color: #6b7280; font-size: 0.85rem;">Hidden until published</p>
      </div>
      <div style="width: 50px; height: 50px; background: #f3f4f6; border-radius: 10px; display: flex; align-items: center; justify-content: center; color: #6b7280; font-size: 1.5rem; flex-shrink: 0;">
        <i class="bi bi-file-earmark-text"></i>
      </div>
    </div>
  </div>

  <!-- Questions Card -->
  <div style="background: white; border-radius: 12px; padding: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.06); border: 1px solid #e5e7eb; border-bottom: 3px solid #3b82f6;">
    <div style="display: flex; align-items: flex-start; justify-content: space-between; gap: 1rem;">
      <div style="flex: 1;">
        <p style="margin: 0 0 0.5rem 0; color: #6b7280; font-size: 0.9rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em;">Questions</p>
        <p style="margin: 0; font-weight: 700; color: #3b82f6; font-size: 1.8rem;" id="questionCount">0</p>
        <p style="margin: 0.5rem 0 0 0; color: #6b7280; font-size: 0.85rem;">Keep adding MCQs</p>
      </div>
      <div style="width: 50px; height: 50px; background: #dbeafe; border-radius: 10px; display: flex; align-items: center; justify-content: center; color: #3b82f6; font-size: 1.5rem; flex-shrink: 0;">
        <i class="bi bi-chat-left-text"></i>
      </div>
    </div>
  </div>

  <!-- Time Limit Card -->
  <div style="background: white; border-radius: 12px; padding: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.06); border: 1px solid #e5e7eb; border-bottom: 3px solid #f59e0b;">
    <div style="display: flex; align-items: flex-start; justify-content: space-between; gap: 1rem;">
      <div style="flex: 1;">
        <p style="margin: 0 0 0.5rem 0; color: #6b7280; font-size: 0.9rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em;">Time Limit</p>
        <p style="margin: 0; font-weight: 700; color: #f59e0b; font-size: 1.8rem;" id="timeLimitDisplay">30 min</p>
        <p style="margin: 0.5rem 0 0 0; color: #6b7280; font-size: 0.85rem;">Adjust as needed</p>
      </div>
      <div style="width: 50px; height: 50px; background: #fef3c7; border-radius: 10px; display: flex; align-items: center; justify-content: center; color: #f59e0b; font-size: 1.5rem; flex-shrink: 0;">
        <i class="bi bi-hourglass-split"></i>
      </div>
    </div>
  </div>
</div>

<!-- Form Section -->
<section style="background: white; border-radius: 12px; padding: 0; box-shadow: 0 1px 3px rgba(0,0,0,0.06); overflow: hidden; margin-bottom: 3rem; border: 1px solid #e5e7eb;">
  <div style="background: white; padding: 1.5rem; border-bottom: 2px solid #3b82f6;">
    <h2 class="h5 mb-0 d-flex align-items-center gap-2" style="font-weight: 700; color: #1f2937;">
      <i class="bi bi-gear" style="font-size: 1.3rem; color: #3b82f6;"></i>Paper Details
    </h2>
  </div>
  <div style="padding: 2rem;">
    <?php foreach ($errors as $e): ?>
      <div style="background: #fee; border-left: 4px solid #dc3545; padding: 1rem; border-radius: 8px; margin-bottom: 1rem; color: #dc3545;">
        <i class="bi bi-exclamation-circle-fill me-2"></i><?= htmlspecialchars($e) ?>
      </div>
    <?php endforeach; ?>
    <?php if ($success): ?>
      <div style="background: #efe; border-left: 4px solid #00d084; padding: 1rem; border-radius: 8px; margin-bottom: 1rem; color: #00d084;">
        <i class="bi bi-check-circle-fill me-2"></i><?= htmlspecialchars($success) ?>
      </div>
    <?php endif; ?>
    
    <form method="post" id="paperForm" accept-charset="UTF-8" enctype="multipart/form-data">
      <?= csrf_field(); ?>
      <input type="hidden" name="autosave" value="0" id="autosaveFlag">
      <input type="hidden" name="draft_paper_id" value="" id="draftPaperId">
      
      <!-- Paper Basics -->
      <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1.5rem; margin-bottom: 2rem;">
        <div>
          <label style="display: block; margin-bottom: 0.5rem; font-weight: 600; color: #333;">
            <i class="bi bi-heading me-1" style="color: #f5576c;"></i>Paper Title
          </label>
          <input class="form-control" name="title" required style="border-radius: 8px; border: 2px solid #e9ecef; padding: 0.75rem; font-size: 1rem;">
        </div>
        <div>
          <label style="display: block; margin-bottom: 0.5rem; font-weight: 600; color: #333;">
            <i class="bi bi-tag me-1" style="color: #4facfe;"></i>Fee (cents)
          </label>
          <input type="number" class="form-control" name="fee_cents" value="0" min="0" style="border-radius: 8px; border: 2px solid #e9ecef; padding: 0.75rem; font-size: 1rem;">
        </div>
        <div>
          <label style="display: block; margin-bottom: 0.5rem; font-weight: 600; color: #333;">
            <i class="bi bi-hourglass-split me-1" style="color: #ffc107;"></i>Time Limit (minutes)
          </label>
          <input type="number" class="form-control" name="time_limit_minutes" id="timeLimit" value="30" min="1" required style="border-radius: 8px; border: 2px solid #e9ecef; padding: 0.75rem; font-size: 1rem;">
        </div>
      </div>

      <!-- Publish Option -->
      <div style="background: #f9f9f9; padding: 1rem; border-radius: 8px; margin-bottom: 2rem; border-left: 4px solid #667eea;">
        <label class="d-flex align-items-center gap-2" style="cursor: pointer; margin: 0;">
          <input type="checkbox" class="form-check-input" id="publishNow" name="publish" value="1" style="width: 20px; height: 20px; cursor: pointer;">
          <span style="font-weight: 600; color: #333;">Publish immediately</span>
        </label>
        <p style="margin: 0.5rem 0 0 28px; color: #666; font-size: 0.85rem;">Paper will be visible to students right away</p>
      </div>

      <hr style="margin: 2rem 0; border: none; border-top: 2px solid #e9ecef;">

      <!-- Questions Section Header -->
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
        <h3 class="h5 mb-0" style="font-weight: 700; color: #1f2937;">
          <i class="bi bi-chat-left-text me-2" style="color: #3b82f6;"></i>Questions
        </h3>
        <button type="button" class="btn btn-primary btn-sm" style="font-weight: 600; padding: 0.5rem 1rem;" onclick="addQuestion()">
          <i class="bi bi-plus-circle me-1"></i>Add Question
        </button>
      </div>

      <!-- Questions Container -->
      <div id="questions" style="display: flex; flex-direction: column; gap: 1.5rem; margin-bottom: 2rem;" aria-live="polite"></div>

      <!-- Form Actions -->
      <div style="display: flex; flex-wrap: wrap; gap: 1rem; padding-top: 2rem; border-top: 1px solid #e5e7eb;">
        <button type="submit" class="btn btn-primary btn-sm" style="font-weight: 600; padding: 0.75rem 1.5rem;">
          <i class="bi bi-save me-1"></i>Save Paper
        </button>
        <button type="button" class="btn btn-outline-primary btn-sm" style="font-weight: 600; padding: 0.75rem 1.5rem;" onclick="addQuestion()">
          <i class="bi bi-plus me-1"></i>Add Another Question
        </button>
        <a class="btn btn-sm btn-outline-secondary" href="<?= htmlspecialchars(app_href('teacher/manage_papers.php')) ?>" style="font-weight: 600; padding: 0.5rem 1rem; text-decoration: none;">
          <i class="bi bi-arrow-left me-1"></i>Back to Papers
        </a>
      </div>

      <p style="margin: 1.5rem 0 0 0; color: #999; font-size: 0.85rem;">
        <i class="bi bi-lightbulb-fill me-1" style="color: #ffc107;"></i><strong>Tip:</strong> Select the correct answer using the radio button for each question, or results will show "N/A".
      </p>
      <div id="autosaveStatus" style="margin-top: 0.5rem; color: #666; font-size: 0.85rem; display: none;">
        <i class="bi bi-arrow-repeat"></i> Auto-saving...
      </div>
    </form>
  </div>
</section>
<script>
let qIndex = 0;
const draftKey = 'paper_form_draft_v1';
let saveDraftTimer;

function debounceSaveDraft(){
  clearTimeout(saveDraftTimer);
  saveDraftTimer = setTimeout(saveDraft, 400);
}

function saveDraft(){
  const form = document.getElementById('paperForm');
  if (!form) return;

  const data = {
    title: form.querySelector('input[name="title"]')?.value || '',
    fee: form.querySelector('input[name="fee_cents"]')?.value || '0',
    timeLimit: form.querySelector('input[name="time_limit_minutes"]')?.value || '',
    publish: form.querySelector('#publishNow')?.checked || false,
    questions: []
  };

  document.querySelectorAll('.question-card').forEach((card) => {
    const qText = card.querySelector('.question-text')?.value || '';
    const marks = card.querySelector('input[name^="marks["]')?.value || '1';
    const options = [];
    let correct = null;

    card.querySelectorAll('input[name^="options"]').forEach((optInput) => {
      options.push(optInput.value || '');
    });

    const radios = card.querySelectorAll('input[type="radio"][name^="correct["]');
    radios.forEach((r, idx) => { if (r.checked) correct = idx; });

    data.questions.push({ text: qText, marks, options, correct });
  });

  try {
    localStorage.setItem(draftKey, JSON.stringify(data));
  } catch (err) {
    console.warn('Could not save draft', err);
  }
}

function clearDraft(){
  try { localStorage.removeItem(draftKey); } catch (err) {}
}

function loadDraft(){
  let raw;
  try {
    raw = localStorage.getItem(draftKey);
  } catch (err) {
    return false;
  }
  if (!raw) return false;

  let data;
  try {
    data = JSON.parse(raw);
  } catch (err) {
    clearDraft();
    return false;
  }

  const form = document.getElementById('paperForm');
  if (!form) return false;

  const titleInput = form.querySelector('input[name="title"]');
  const feeInput = form.querySelector('input[name="fee_cents"]');
  const timeInput = form.querySelector('input[name="time_limit_minutes"]');
  const publishInput = form.querySelector('#publishNow');

  if (titleInput) titleInput.value = data.title || '';
  if (feeInput) feeInput.value = data.fee || '0';
  if (timeInput) timeInput.value = data.timeLimit || '';
  if (publishInput) publishInput.checked = !!data.publish;

  const qWrap = document.getElementById('questions');
  qWrap.innerHTML = '';
  qIndex = 0;

  if (Array.isArray(data.questions) && data.questions.length) {
    data.questions.forEach((q) => addQuestion(q));
  } else {
    addQuestion();
  }

  updateQuestionCount();
  updateTimeDisplay();
  return true;
}

function showMathHelper(btn) {
  const card = btn.closest('.question-card');
  const textarea = card ? card.querySelector('.question-text') : null;
  if (!textarea) return;
  const modal = document.createElement('div');
  modal.style.cssText = 'position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.7); display: flex; align-items: center; justify-content: center; z-index: 9999; padding: 1rem;';
  
  // Symbol categories like Google Forms
  const symbolCategories = {
    'Basic': [
      {char: '+', latex: '+'},
      {char: '−', latex: '-'},
      {char: '×', latex: '\\times'},
      {char: '÷', latex: '\\div'},
      {char: '=', latex: '='},
      {char: '≠', latex: '\\neq'},
      {char: '>', latex: '>'},
      {char: '<', latex: '<'},
      {char: '≥', latex: '\\geq'},
      {char: '≤', latex: '\\leq'},
    ],
    'Fractions & Roots': [
      {char: '⁄', latex: '\\frac{}{}'}, 
      {char: '√', latex: '\\sqrt{}'},
      {char: '∛', latex: '\\sqrt[3]{}'},
      {char: '∜', latex: '\\sqrt[4]{}'},
    ],
    'Exponents & Subscripts': [
      {char: 'x²', latex: '^2'},
      {char: 'xⁿ', latex: '^{}'},
      {char: 'x₂', latex: '_{}'},
      {char: '()', latex: '()'},
      {char: '[]', latex: '[]'},
    ],
    'Greek Letters': [
      {char: 'α', latex: '\\alpha'},
      {char: 'β', latex: '\\beta'},
      {char: 'γ', latex: '\\gamma'},
      {char: 'δ', latex: '\\delta'},
      {char: 'π', latex: '\\pi'},
      {char: 'Σ', latex: '\\Sigma'},
      {char: 'θ', latex: '\\theta'},
      {char: 'ω', latex: '\\omega'},
      {char: 'λ', latex: '\\lambda'},
      {char: 'μ', latex: '\\mu'},
    ],
    'Calculus': [
      {char: '∫', latex: '\\int'},
      {char: '∫∫', latex: '\\iint'},
      {char: '∑', latex: '\\sum'},
      {char: 'Π', latex: '\\prod'},
      {char: '∞', latex: '\\infty'},
      {char: '∂', latex: '\\partial'},
      {char: '∇', latex: '\\nabla'},
      {char: '∆', latex: '\\Delta'},
    ],
    'Logic & Sets': [
      {char: '∀', latex: '\\forall'},
      {char: '∃', latex: '\\exists'},
      {char: '∈', latex: '\\in'},
      {char: '∉', latex: '\\notin'},
      {char: '⊂', latex: '\\subset'},
      {char: '∪', latex: '\\cup'},
      {char: '∩', latex: '\\cap'},
      {char: '∅', latex: '\\emptyset'},
    ],
    'Arrows': [
      {char: '←', latex: '\\leftarrow'},
      {char: '→', latex: '\\rightarrow'},
      {char: '↑', latex: '\\uparrow'},
      {char: '↓', latex: '\\downarrow'},
      {char: '⇒', latex: '\\Rightarrow'},
      {char: '⟹', latex: '\\implies'},
    ],
  };
  
  let htmlContent = `
    <div style="background: white; border-radius: 12px; padding: 0; max-width: 900px; box-shadow: 0 10px 40px rgba(0,0,0,0.3); max-height: 85vh; overflow: hidden; display: flex; flex-direction: column;">
      <!-- Header -->
      <div style="background: white; border-bottom: 2px solid #3b82f6; padding: 1.5rem; display: flex; justify-content: space-between; align-items: center;">
        <h4 style="margin: 0; font-weight: 700; font-size: 1.2rem; color: #1f2937;">
          <i class="bi bi-calculator-fill me-2" style="color: #3b82f6;"></i>Insert Math Equation
        </h4>
        <button type="button" style="background: none; border: none; font-size: 1.8rem; cursor: pointer; color: #6b7280; opacity: 0.8;" onclick="this.closest('[style*=position]').remove()">×</button>
      </div>
      
      <!-- LaTeX Input & Preview -->
      <div style="background: #f8f9fa; padding: 1rem; border-bottom: 1px solid #e9ecef;">
        <div class="grid-auto-fit" style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
          <div>
            <label style="display: block; margin-bottom: 0.5rem; font-weight: 600; color: #333; font-size: 0.9rem;">LaTeX Code</label>
            <input type="text" id="latexInput" placeholder="e.g., x = \\frac{-b \\pm \\sqrt{b^2-4ac}}{2a}" style="width: 100%; border-radius: 6px; border: 1px solid #ddd; padding: 0.75rem; font-family: monospace; font-size: 0.9rem; min-height: 44px;" />
            <small style="display: block; margin-top: 0.5rem; color: #666; font-size: 0.85rem;">Type or click symbols below</small>
          </div>
          <div>
            <label style="display: block; margin-bottom: 0.5rem; font-weight: 600; color: #333; font-size: 0.9rem;">Live Preview</label>
            <div id="mathPreview" style="border-radius: 6px; border: 1px solid #ddd; padding: 0.75rem; background: white; min-height: 44px; font-size: 1.1rem; display: flex; align-items: center; justify-content: center; overflow: auto;">
              (preview here)
            </div>
          </div>
        </div>
      </div>
      
      <!-- Symbol Categories (Tabs) -->
      <div style="display: flex; border-bottom: 1px solid #e9ecef; background: white; overflow-x: auto;">`;
  
  Object.keys(symbolCategories).forEach((cat, idx) => {
    const isActive = idx === 0 ? 'background: #f3f4f6; border-bottom: 3px solid #3b82f6;' : '';
    htmlContent += `
      <button type="button" class="category-tab" data-category="${cat}" style="padding: 0.75rem 1rem; border: none; cursor: pointer; font-weight: 600; color: #6b7280; ${isActive} flex-shrink: 0; transition: all 0.2s;">
        ${cat}
      </button>`;
  });
  
  htmlContent += `</div>
      
      <!-- Symbol Grid -->
      <div style="flex: 1; overflow-y: auto; padding: 1.5rem; padding-top: 1rem;">
        <div id="symbolGrid" class="grid-auto-fit" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(60px, 1fr)); gap: 0.75rem;"></div>
      </div>
      
      <!-- Action Buttons -->
      <div style="background: #f8f9fa; padding: 1rem; border-top: 1px solid #e9ecef; display: flex; gap: 0.75rem; flex-wrap: wrap;">
        <button type="button" class="btn btn-primary" style="flex: 1; min-height: 44px; cursor: pointer;" onclick="insertMathEquation()">
          <i class="bi bi-check-circle me-1"></i>OK
        </button>
        <button type="button" class="btn btn-outline-secondary" style="flex: 1; min-height: 44px; cursor: pointer;" onclick="this.closest('[style*=position]').remove()">
          Cancel
        </button>
      </div>
    </div>
  `;
  
  modal.innerHTML = htmlContent;
  document.body.appendChild(modal);
  
  // Store textarea reference
  window.currentTextarea = textarea;
  
  // Initialize symbol grid
  function renderSymbols(category) {
    const grid = document.getElementById('symbolGrid');
    grid.innerHTML = '';
    
    (symbolCategories[category] || symbolCategories['Basic']).forEach(symbol => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.style.cssText = `
        background: white; border: 2px solid #e9ecef; border-radius: 6px; padding: 1rem;
        cursor: pointer; font-weight: 600; font-size: 1.2rem; color: #333;
        transition: all 0.2s; text-align: center;
      `;
      btn.textContent = symbol.char;
      btn.title = symbol.latex;
      btn.onmouseover = () => btn.style.cssText += 'background: #f0f0f0; border-color: #667eea;';
      btn.onmouseout = () => btn.style.cssText = `
        background: white; border: 2px solid #e9ecef; border-radius: 6px; padding: 1rem;
        cursor: pointer; font-weight: 600; font-size: 1.2rem; color: #333;
        transition: all 0.2s; text-align: center;
      `;
      btn.onclick = () => {
        const input = document.getElementById('latexInput');
        input.value += symbol.latex + ' ';
        input.focus();
        updatePreview();
      };
      grid.appendChild(btn);
    });
  }
  
  // Category tab switching
  document.querySelectorAll('.category-tab').forEach(tab => {
    tab.onclick = () => {
      document.querySelectorAll('.category-tab').forEach(t => t.style.cssText = 'padding: 0.75rem 1rem; border: none; cursor: pointer; font-weight: 600; color: #333; flex-shrink: 0; transition: all 0.2s;');
      tab.style.cssText = 'padding: 0.75rem 1rem; border: none; cursor: pointer; font-weight: 600; color: #333; flex-shrink: 0; transition: all 0.2s; background: #f0f0f0; border-bottom: 3px solid #667eea;';
      renderSymbols(tab.dataset.category);
    };
  });
  
  // Live preview
  function updatePreview() {
    const input = document.getElementById('latexInput');
    const preview = document.getElementById('mathPreview');
    preview.textContent = input.value || '(preview here)';
    // Re-render if MathJax available
    if (window.MathJax && window.MathJax.typesetPromise) {
      try {
        window.MathJax.typesetPromise([preview]).catch(e => {});
      } catch(e) {}
    }
  }
  
  document.getElementById('latexInput').oninput = updatePreview;
  
  // Initial render
  renderSymbols('Basic');
  
  // Close on modal background click
  modal.addEventListener('click', (e) => {
    if (e.target === modal) modal.remove();
  });
}

function insertMathEquation() {
  const input = document.getElementById('latexInput');
  const latexCode = input.value.trim();
  
  if (!latexCode) {
    alert('Please enter or select LaTeX code');
    return;
  }
  
  // Wrap in $$
  const equation = '$$' + latexCode + '$$';
  
  if (window.currentTextarea) {
    const start = window.currentTextarea.selectionStart;
    const end = window.currentTextarea.selectionEnd;
    const text = window.currentTextarea.value;
    
    window.currentTextarea.value = text.substring(0, start) + ' ' + equation + ' ' + text.substring(end);
    window.currentTextarea.focus();
    window.currentTextarea.dispatchEvent(new Event('input', { bubbles: true }));
  }
  
  // Close modal
  document.querySelector('[style*="position: fixed"][style*="z-index: 9999"]')?.remove();
}

// Backup insert functions for legacy template system
function insertMath(formula) {
  if (window.currentTextarea) {
    const start = window.currentTextarea.selectionStart;
    const end = window.currentTextarea.selectionEnd;
    const text = window.currentTextarea.value;
    
    window.currentTextarea.value = text.substring(0, start) + ' ' + formula + ' ' + text.substring(end);
    window.currentTextarea.focus();
    window.currentTextarea.dispatchEvent(new Event('input', { bubbles: true }));
  }
  document.body.querySelector('[style*="position: fixed"]')?.remove();
}

function insertCustomMath() {
  const customMath = document.getElementById('customMath')?.value;
  if (customMath?.trim()) {
    insertMath(customMath);
  }
}

function updateQuestionCount(){
  const count = document.querySelectorAll('.question-card').length;
  document.getElementById('questionCount').textContent = count;
  // Update all question numbers
  document.querySelectorAll('.question-card').forEach((card, index) => {
    const header = card.querySelector('h4');
    if (header) {
      header.innerHTML = `<i class="bi bi-chat-left-text me-2" style="color: #4facfe;"></i>Question #${index + 1}`;
    }
  });
}

function updateTimeDisplay(){
  const mins = document.getElementById('timeLimit').value;
  document.getElementById('timeLimitDisplay').textContent = mins + ' min';
}

function addQuestionAfter(btn){
  const currentCard = btn.closest('.question-card');
  const allCards = document.querySelectorAll('.question-card');
  let insertIndex = 0;
  for (let i = 0; i < allCards.length; i++) {
    if (allCards[i] === currentCard) {
      insertIndex = i + 1;
      break;
    }
  }
  // Add the new question to the DOM after this one
  const newCard = createNewQuestionCard();
  if (insertIndex < allCards.length) {
    allCards[insertIndex].parentNode.insertBefore(newCard, allCards[insertIndex]);
  } else {
    document.getElementById('questions').appendChild(newCard);
  }
  updateQuestionCount();
  debounceSaveDraft();
}

function createNewQuestionCard(){
  const currentIndex = qIndex;
  const wrap = document.createElement('div');
  wrap.className = 'question-card';
  wrap.style.cssText = 'padding: 1.5rem; background: white; border: 2px solid #e9ecef; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.08);';
  wrap.innerHTML = `
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; padding-bottom: 1rem; border-bottom: 2px solid #e9ecef;">
      <h4 style="margin: 0; font-weight: 700; color: #333; font-size: 1rem;">
        <i class="bi bi-chat-left-text me-2" style="color: #4facfe;"></i>Question #${currentIndex + 1}
      </h4>
      <button type="button" class="btn btn-sm" style="background: #fee; color: #dc3545; border: none; border-radius: 6px; padding: 0.5rem 0.75rem; font-weight: 600;" onclick="removeQuestion(this)">
        <i class="bi bi-trash"></i> Remove
      </button>
    </div>
    <div style="display: grid; grid-template-columns: 1fr auto; gap: 1.5rem; margin-bottom: 1.5rem;" class="grid-auto-fit">
      <div>
        <label style="display: block; margin-bottom: 0.5rem; font-weight: 600; color: #333; font-size: 0.9rem;">Question Text</label>
        <textarea class="form-control question-text" name="questions[${currentIndex}]" rows="3" placeholder="Type question in Sinhala or English" required style="border-radius: 8px; border: 2px solid #e9ecef; padding: 0.75rem; font-size: 1rem; font-family: 'Noto Sans Sinhala', 'Segoe UI', sans-serif;"></textarea>
        <button type="button" class="btn btn-sm" style="margin-top: 0.5rem; background: #667eea; color: white; border: none; border-radius: 6px; padding: 0.4rem 0.75rem; font-weight: 600; font-size: 0.85rem;" onclick="showMathHelper(this)">
          <i class="bi bi-calculator-fill me-1"></i>Math Symbols
        </button>
      </div>
      <div>
        <label style="display: block; margin-bottom: 0.5rem; font-weight: 600; color: #333; font-size: 0.9rem;">Marks</label>
        <input type="number" class="form-control" name="marks[${currentIndex}]" min="1" value="1" required style="border-radius: 8px; border: 2px solid #e9ecef; padding: 0.75rem; font-size: 1rem;">
      </div>
    </div>
    <div style="margin-bottom: 1.5rem; padding: 1rem; background: #f8f9fa; border-radius: 8px; border: 2px dashed #dee2e6;">
      <label style="display: block; margin-bottom: 0.5rem; font-weight: 600; color: #333; font-size: 0.9rem;">
        <i class="bi bi-file-earmark-image me-1" style="color: #ffc107;"></i>Add Image or PDF (Optional)
      </label>
      <input type="file" class="form-control" name="question_images[${currentIndex}]" accept="image/png,image/jpeg,image/gif,image/webp,application/pdf" style="border-radius: 6px; border: 1px solid #dee2e6; padding: 0.5rem; font-size: 0.9rem;">
      <small class="text-muted d-block mt-2">PNG, JPEG, GIF, WebP, or PDF (max 5MB)</small>
      <div id="img_preview_${currentIndex}" style="margin-top: 1rem; display: none;">
        <img id="img_${currentIndex}" style="max-width: 100%; max-height: 200px; border-radius: 6px; border: 1px solid #dee2e6;">
      </div>
    </div>
    <div>
      <label style="display: block; margin-bottom: 0.75rem; font-weight: 600; color: #333; font-size: 0.9rem;">
        <i class="bi bi-list-check me-1" style="color: #667eea;"></i>Options
      </label>
      <div id="opts_${currentIndex}" style="display: flex; flex-direction: column; gap: 0.75rem;"></div>
      <button type="button" class="btn btn-sm" style="background: #e7f3ff; color: #4facfe; border: 2px solid #4facfe; margin-top: 1rem; border-radius: 6px; padding: 0.5rem 1rem; font-weight: 600;" onclick="addOption(${currentIndex})">
        <i class="bi bi-plus me-1"></i>Add Option
      </button>
    </div>
    <div style="background: #fffbf0; border-left: 4px solid #ffc107; padding: 1rem; border-radius: 8px; margin-top: 1.5rem; margin-bottom: 1.5rem;">
      <p style="margin: 0; color: #ff9800; font-size: 0.9rem;">
        <i class="bi bi-exclamation-triangle-fill me-1"></i><strong>Important:</strong> Select the correct answer using the radio button, or students will see "N/A" in results!
      </p>
    </div>
    <div style="padding-top: 1rem; border-top: 2px solid #e9ecef; display: flex; justify-content: flex-end;">
      <button type="button" class="btn" style="background: #e8f5e9; color: #2e7d32; border: 2px solid #4caf50; border-radius: 6px; padding: 0.6rem 1.2rem; font-weight: 600; font-size: 0.95rem;" onclick="addQuestionAfter(this)">
        <i class="bi bi-plus-circle me-1"></i>Add Question After This
      </button>
    </div>
  `;
  
  const textarea = wrap.querySelector('.question-text');
  const optsWrap = wrap.querySelector('#opts_' + currentIndex);
  const marksInput = wrap.querySelector(`input[name="marks[${currentIndex}]"]`);
  
  // File preview
  wrap.querySelector(`input[name="question_images[${currentIndex}]"]`).addEventListener('change', function(){
    const preview = wrap.querySelector(`#img_preview_${currentIndex}`);
    const img = wrap.querySelector(`#img_${currentIndex}`);
    if (this.files.length > 0) {
      const reader = new FileReader();
      reader.onload = e => {
        img.src = e.target.result;
        preview.style.display = 'block';
      };
      reader.readAsDataURL(this.files[0]);
    } else {
      preview.style.display = 'none';
    }
  });
  
  textarea.addEventListener('input', debounceSaveDraft);
  marksInput.addEventListener('input', debounceSaveDraft);
  
  qIndex++;
  return wrap;
}

function addQuestion(prefill){
  const wrap = createNewQuestionCard();
  document.getElementById('questions').appendChild(wrap);
  
  const currentIndex = qIndex - 1; // qIndex was incremented in createNewQuestionCard
  const optsWrap = wrap.querySelector('#opts_' + currentIndex);
  const textarea = wrap.querySelector('.question-text');
  const marksInput = wrap.querySelector(`input[name="marks[${currentIndex}]"]`);
  
  if (prefill && Array.isArray(prefill.options) && prefill.options.length) {
    optsWrap.innerHTML = '';
    prefill.options.forEach((optText, idx) => addOption(currentIndex, optText, prefill.correct === idx));
  } else {
    addOption(currentIndex);
    addOption(currentIndex);
  }

  if (prefill) {
    textarea.value = prefill.text || '';
    marksInput.value = prefill.marks || '1';
  }

  updateQuestionCount();
  debounceSaveDraft();
}

function removeQuestion(btn){

  btn.closest('.question-card').remove();
  updateQuestionCount();
  debounceSaveDraft();
}

function showOptionAttachmentPreview(qIdx, optIdx, url, isPdf, clearOnly){
  const img = document.getElementById(`opt_img_${qIdx}_${optIdx}`);
  const imgWrap = document.getElementById(`opt_img_wrap_${qIdx}_${optIdx}`);
  const pdfWrap = document.getElementById(`opt_pdf_wrap_${qIdx}_${optIdx}`);
  const pdfLink = document.getElementById(`opt_pdf_link_${qIdx}_${optIdx}`);
  const pdfEmbed = document.getElementById(`opt_pdf_embed_${qIdx}_${optIdx}`);
  if (!imgWrap || !pdfWrap) return;
  if (clearOnly || !url) {
    imgWrap.style.display = 'none';
    pdfWrap.style.display = 'none';
    if (img) img.removeAttribute('src');
    if (pdfEmbed) pdfEmbed.removeAttribute('src');
    if (pdfLink) pdfLink.removeAttribute('href');
    return;
  }
  if (isPdf) {
    imgWrap.style.display = 'none';
    if (pdfLink) pdfLink.href = url;
    if (pdfEmbed) pdfEmbed.src = url;
    pdfWrap.style.display = 'block';
  } else {
    if (img) img.src = url;
    imgWrap.style.display = 'block';
    pdfWrap.style.display = 'none';
  }
}

function addOption(i, value = '', isCorrect = false){
  const oWrap = document.getElementById('opts_' + i);
  const count = oWrap.querySelectorAll('input[type="text"]').length;
  const inputGroup = document.createElement('div');
  inputGroup.style.cssText = 'display: flex; flex-direction: column; gap: 0.5rem;';
  inputGroup.innerHTML = `
    <div style="display: flex; gap: 0.5rem; align-items: center; flex-wrap: wrap;">
      <input type="radio" name="correct[${i}]" value="${count}" id="correct_${i}_${count}" style="width: 20px; height: 20px; cursor: pointer; margin-right: 0.5rem;">
      <input type="text" class="form-control" name="options[${i}][${count}]" placeholder="Option text" required style="border-radius: 6px; border: 2px solid #e9ecef; padding: 0.5rem; font-size: 0.9rem; flex: 1; min-width: 200px;">
      <input type="file" class="form-control form-control-sm" name="option_attachments[${i}][${count}]" accept="image/png,image/jpeg,image/gif,image/webp,application/pdf" style="max-width: 220px;">
      <button class="btn btn-sm" type="button" style="background: #fee; color: #dc3545; border: none; border-radius: 6px; padding: 0.5rem 0.75rem; font-weight: 600; white-space: nowrap;">
        <i class="bi bi-x"></i> Remove
      </button>
    </div>
    <div id="opt_img_wrap_${i}_${count}" style="display: none; margin-left: 2.5rem;">
      <img id="opt_img_${i}_${count}" style="max-width: 100%; max-height: 160px; border-radius: 6px; border: 1px solid #dee2e6;">
    </div>
    <div id="opt_pdf_wrap_${i}_${count}" style="display: none; margin-left: 2.5rem;">
      <a id="opt_pdf_link_${i}_${count}" href="#" target="_blank" rel="noopener">View PDF</a>
      <embed id="opt_pdf_embed_${i}_${count}" type="application/pdf" style="width: 100%; height: 200px; border: 1px solid #dee2e6; border-radius: 6px; margin-top: 0.5rem;">
    </div>
  `;
  oWrap.appendChild(inputGroup);

  const radio = inputGroup.querySelector('input[type="radio"]');
  const textInput = inputGroup.querySelector('input[type="text"]');
  const fileInput = inputGroup.querySelector('input[type="file"]');
  const removeBtn = inputGroup.querySelector('button');

  if (value) textInput.value = value;
  if (isCorrect) radio.checked = true;

  textInput.addEventListener('input', debounceSaveDraft);
  radio.addEventListener('change', debounceSaveDraft);
  if (fileInput) {
    fileInput.addEventListener('change', () => {
      const file = fileInput.files[0];
      if (file) {
        const isPdf = file.type === 'application/pdf' || /\.pdf$/i.test(file.name || '');
        const url = URL.createObjectURL(file);
        showOptionAttachmentPreview(i, count, url, isPdf);
      } else {
        showOptionAttachmentPreview(i, count, '', false, true);
      }
    });
  }
  removeBtn.addEventListener('click', () => {
    inputGroup.remove();
    debounceSaveDraft();
  });
  debounceSaveDraft();
}
document.addEventListener('DOMContentLoaded', () => {
  const restored = loadDraft();
  if (!restored) {
    addQuestion();
    updateTimeDisplay();
  }

  const titleInput = document.querySelector('input[name="title"]');
  const feeInput = document.querySelector('input[name="fee_cents"]');
  const timeInput = document.querySelector('input[name="time_limit_minutes"]');
  const publishInput = document.getElementById('publishNow');

  if (titleInput) titleInput.addEventListener('input', debounceSaveDraft);
  if (feeInput) feeInput.addEventListener('input', debounceSaveDraft);
  if (timeInput) timeInput.addEventListener('input', () => { updateTimeDisplay(); debounceSaveDraft(); });
  if (publishInput) publishInput.addEventListener('change', debounceSaveDraft);

  // Keep draft after tab close to allow crash recovery

  // Update time limit display on change
  const timeField = document.getElementById('timeLimit');
  if (timeField) timeField.addEventListener('change', updateTimeDisplay);
  
  // Add event delegation for file inputs
  document.addEventListener('change', function(e) {
    if(e.target.name && e.target.name.startsWith('question_images')) {
      const file = e.target.files[0];
      if(file){
        const reader = new FileReader();
        const match = e.target.name.match(/\[(\d+)\]/);
        const index = match ? match[1] : null;
        if(index){
          reader.onload = function(event) {
            const preview = document.getElementById('img_preview_' + index);
            const img = document.getElementById('img_' + index);
            if(preview && img){
              img.src = event.target.result;
              preview.style.display = 'block';
            }
          };
          reader.readAsDataURL(file);
        }
      }
    }
  });

  // Validate correct answers before submit
  document.getElementById('paperForm').addEventListener('submit', (e) => {
    const questions = document.querySelectorAll('.question-card');
    let hasError = false;
    
    questions.forEach((card, idx) => {
      const radioName = `correct[${idx}]`;
      const radios = document.querySelectorAll(`input[name="${radioName}"]`);
      const isChecked = Array.from(radios).some(r => r.checked);
      
      if (!isChecked && radios.length > 0) {
        hasError = true;
        const alertBox = card.querySelector('div[style*="background: #fffbf0"]');
        if (alertBox) {
          alertBox.style.background = '#fee';
          alertBox.style.borderColor = '#dc3545';
          alertBox.innerHTML = '<p style="margin: 0; color: #dc3545; font-size: 0.9rem;"><i class="bi bi-exclamation-triangle-fill me-1"></i><strong>ERROR:</strong> You must select which option is correct!</p>';
        }
      }
    });
    
    if (hasError) {
      e.preventDefault();
      alert('Please select the correct answer for all questions before submitting!');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      clearDraft();
    }
  });
  
  // Trigger KaTeX rendering after page loads
  if (window.renderMathInElement) {
    try {
      window.renderMathInElement(document.body, {
        delimiters: [
          {left: '$$', right: '$$', display: true},
          {left: '$', right: '$', display: false},
          {left: '\\[', right: '\\]', display: true},
          {left: '\\(', right: '\\)', display: false}
        ]
      });
    } catch(err) {
      console.log('Initial KaTeX render:', err.message);
    }
  }

  // ==== 30s in-tab autosave to backend ====
  const form = document.getElementById('paperForm');
  const draftIdEl = document.getElementById('draftPaperId');
  const statusEl = document.getElementById('autosaveStatus');
  const autosaveFlag = document.getElementById('autosaveFlag');
  let isDirty = true; // assume dirty at start
  let lastSentSnapshot = '';
  let isSaving = false;
  let autosaveDisabled = false;
  let autosaveIntervalId = null;

  function snapshotForm() {
    // Lightweight snapshot (ignore files to reduce churn)
    const obj = {
      title: form.querySelector('input[name="title"]').value,
      fee: form.querySelector('input[name="fee_cents"]').value,
      time: form.querySelector('input[name="time_limit_minutes"]').value,
      publish: form.querySelector('#publishNow').checked,
      questions: Array.from(document.querySelectorAll('.question-card')).map((card, idx) => ({
        text: card.querySelector('.question-text')?.value || '',
        marks: card.querySelector(`input[name^="marks["]`)?.value || '1',
        options: Array.from(card.querySelectorAll(`#opts_${idx} input[type="text"]`)).map(i => i.value),
        correct: Array.from(card.querySelectorAll(`input[name="correct[${idx}]"]`)).findIndex(r => r.checked)
      }))
    };
    try { return JSON.stringify(obj); } catch { return Math.random().toString(); }
  }

  function markDirty() { isDirty = true; }

  // Mark dirty on common edits
  form.addEventListener('input', markDirty, true);
  form.addEventListener('change', markDirty, true);

  async function autosaveNow() {
    if (autosaveDisabled) return;
    if (isSaving) return;
    const snap = snapshotForm();
    if (!isDirty && snap === lastSentSnapshot) return;
    if (document.visibilityState !== 'visible') return;

    // Prepare payload
    const fd = new FormData(form);
    fd.set('autosave', '1');
    // Ensure draft id is included
    if (draftIdEl.value) fd.set('draft_paper_id', draftIdEl.value);

    isSaving = true;
    statusEl.style.display = 'inline';
    try {
      const res = await fetch(window.location.href, {
        method: 'POST',
        body: fd,
        credentials: 'same-origin'
      });
      const data = await res.json().catch(() => ({}));
      if (res.ok && data && data.ok) {
        if (data.paper_id) {
          draftIdEl.value = data.paper_id;
        }
        if (data.csrf) {
          const csrfEl = form.querySelector('input[name="_csrf"]');
          if (csrfEl) csrfEl.value = data.csrf;
        }
        lastSentSnapshot = snap;
        isDirty = false;
      } else {
        if (data && data.csrf) {
          const csrfEl = form.querySelector('input[name="_csrf"]');
          if (csrfEl) csrfEl.value = data.csrf;
          // If invalid CSRF, mark dirty and retry once shortly
          if (res.status === 400 && String(data.error||'').toLowerCase().includes('csrf')) {
            isDirty = true;
            setTimeout(() => { if (document.visibilityState === 'visible' && document.hasFocus()) autosaveNow(); }, 800);
          }
        }
        console.warn('Autosave failed', data);
      }
    } catch (e) {
      console.warn('Autosave error', e);
    } finally {
      isSaving = false;
      statusEl.style.display = 'none';
    }
  }

  // Every 30s when tab is visible and focused
  autosaveIntervalId = setInterval(() => { if (document.visibilityState === 'visible' && document.hasFocus()) autosaveNow(); }, 60000);
  // Also do a first autosave after short delay to capture early work
  setTimeout(() => { if (document.visibilityState === 'visible' && document.hasFocus()) autosaveNow(); }, 10000);

  // Suppress autosave during manual submit
  form.addEventListener('submit', () => {
    autosaveDisabled = true;
    if (autosaveIntervalId) { clearInterval(autosaveIntervalId); }
    if (autosaveFlag) autosaveFlag.value = '0';
  });
});
</script>
<?php render_footer(); ?>